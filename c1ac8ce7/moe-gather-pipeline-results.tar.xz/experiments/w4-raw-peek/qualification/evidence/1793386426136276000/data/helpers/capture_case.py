"""Capture the actual uninstrumented kernel artifacts and resources before smoke."""
import hashlib,json,os,runpy,subprocess,sys,time
from pathlib import Path
import cutlass.cute as cute
import cuda.bindings.driver as cuda
mode=sys.argv[sys.argv.index('--mode')+1]
if mode=='w4a16':from register_guard_w4 import install
else:from register_guard import install
finish=install();original=cute.compile
out=Path(os.environ['CODEGEN_OUTPUT']);out.mkdir(parents=True,exist_ok=False)
receipt={'started':time.time(),'compiler_options_changed':False,'artifact_retention':'CUTE_DSL_KEEP=ptx,cubin','kernels':[]}
def save():(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
def checked(v):
 assert v[0]==cuda.CUresult.CUDA_SUCCESS,v
 return v[1] if len(v)==2 else v[1:]
def normalized(v):
 if v is None or isinstance(v,(str,int,float,bool)):return v
 if isinstance(v,(tuple,list)):return [normalized(x) for x in v]
 return str(v)
def compile(*args,**kwargs):
 kernel=getattr(args[0],'__self__',args[0]);kind=type(kernel).__name__
 compiled=original(*args,**kwargs)
 if kind not in ('Sm100W4A16GroupedGemmKernel','Sm100BlockScaledGroupedGemmKernel','_MoeFinalizeKernel'):return compiled
 i=len(receipt['kernels']);stem=f'{i:02d}-{kind}'
 ptx=compiled.__ptx__;cubin=compiled.__cubin__
 cubin_path=str(cubin) if isinstance(cubin,str) else None
 if cubin_path is not None:cubin=Path(cubin_path).read_bytes()
 assert isinstance(ptx,str) and '.version ' in ptx,('Missing native PTX contents',kind,ptx)
 assert isinstance(cubin,bytes) and cubin.startswith(b'\x7fELF'),('Missing native ELF cubin',kind,type(cubin))
 (out/(stem+'.ptx')).write_text(ptx);(out/(stem+'.cubin')).write_bytes(cubin)
 sass=subprocess.check_output(['/usr/local/cuda/bin/cuobjdump','--dump-sass',str(out/(stem+'.cubin'))],text=True)
 (out/(stem+'.sass')).write_text(sass)
 resource_text=subprocess.check_output(['/usr/local/cuda/bin/cuobjdump','--dump-resource-usage',str(out/(stem+'.cubin'))],text=True)
 (out/(stem+'.resources.txt')).write_text(resource_text)
 library=cuda.CUlibrary(int(compiled.library));device=checked(cuda.cuCtxGetDevice());count=int(checked(cuda.cuLibraryGetKernelCount(library)));assert count==1
 handle=checked(cuda.cuLibraryEnumerateKernels(count,library))[0]
 native={key:int(checked(cuda.cuKernelGetAttribute(getattr(cuda.CUfunction_attribute,'CU_FUNC_ATTRIBUTE_'+attr),handle,device))) for key,attr in [('registers','NUM_REGS'),('max_threads','MAX_THREADS_PER_BLOCK'),('local_bytes','LOCAL_SIZE_BYTES'),('static_shared_bytes','SHARED_SIZE_BYTES'),('binary_version','BINARY_VERSION')]}
 attrs={name:normalized(getattr(kernel,name)) for name in ('num_stages','num_a_load_stages','num_transform_stages','num_c_stage','epi_tile_n','gated','activation_type','gather_input','scatter_output','mma_tiler_mnk','mma_tiler','tile_k','native_mma_k','route_tile','channel_tiles','cta_group_size','use_2cta_instrs','use_clc_scheduler','enable_pdl','hidden_size','top_k','threads','vectors_per_thread','input_is_expanded') if hasattr(kernel,name)}
 if kind=='Sm100BlockScaledGroupedGemmKernel':
  attrs.update(overlap_acc=kernel.overlap_acc,bulk_tokens=kernel.epilogue.bulk_tokens,bulk_stages=kernel.epilogue.bulk_stages)
 receipt['kernels'].append({'kind':kind,'stem':stem,'configuration':attrs,'compile_options':kwargs.get('options',''),'ptx_sha256':hashlib.sha256(ptx.encode()).hexdigest(),'cubin_sha256':hashlib.sha256(cubin).hexdigest(),'sass_sha256':hashlib.sha256(sass.encode()).hexdigest(),'native_resources':native,'native_cubin_artifact':cubin_path})
 save();return compiled
cute.compile=compile;save();code=1
try:
 runpy.run_path(str(Path(__file__).with_name('smoke_case.py')),run_name='__main__');code=0
finally:
 cute.compile=original;finish(code);receipt.update(finished=time.time(),exitstatus=code);save()
