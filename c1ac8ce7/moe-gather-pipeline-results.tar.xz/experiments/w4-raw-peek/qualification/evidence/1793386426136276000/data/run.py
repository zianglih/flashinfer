"""Bounded exact/native gate on GPU7; no timing or production-code overrides."""
from pathlib import Path
import hashlib,json,os,signal,subprocess,sys,time
ROOT=Path('/data/ziangli/flashinfer-moe-gather-pipeline')
OUT=ROOT/'experiments/w4-raw-peek/qualification';H=OUT/'helpers';GPU=7
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sources={r:json.loads((OUT/f'source-{r}.json').read_text())for r in ('control','candidate')}
helpers={p.name:sha(p)for p in H.glob('*.py')}
receipt=dict(started=time.time(),complete=False,passed=False,gpu=GPU,runs=[],source_hashes={r:sha(OUT/f'source-{r}.json')for r in sources},helpers=helpers,boundary='Six paired public-API exact cases spanning public N16–256, one/two CTA, old/new gated layout, SwiGLU/SiTU/ReLU2, partial/full K, CLC/static and PDL; same native compile options/resource guards. Correctness-only cluster cap and selected tactics. No timing, sanitizer, retuning or source mutation.')
path=OUT/'receipt.json';assert not path.exists()
def save():path.write_text(json.dumps(receipt,indent=2)+'\n')
def verify(full=False):
 for n,d in helpers.items():assert sha(H/n)==d,n
 for role,s in sources.items():
  assert sha(OUT/f'source-{role}.json')==receipt['source_hashes'][role]
  assert s['head']=='2b8eb9d8f72ceda3952fbb05054fee97173fc9c7'
  check=s if full else json.loads((OUT/f'guard-{role}.json').read_text())
  for n,d in check['source_sha256'].items():assert sha(Path(s['repo'])/n)==d,(role,n)
def idle():
 apps=subprocess.check_output(['nvidia-smi','-i',str(GPU),'--query-compute-apps=pid','--format=csv,noheader'],text=True).strip();assert not apps,apps
 return subprocess.check_output(['nvidia-smi','-i',str(GPU),'--query-gpu=uuid,name,memory.used,utilization.gpu','--format=csv,noheader,nounits'],text=True).strip()
base={k:v for k,v in os.environ.items()if not k.startswith(('FLASHINFER_','TRTLLM_','CUTE_DSL_','REG_GUARD_','CODEGEN_','SMOKE_','GRAPH_','MEGA_'))and k not in ('CUDA_VISIBLE_DEVICES','PYTHONOPTIMIZE')}
base.update(FLASHINFER_CUDA_ARCH_LIST='10.3a',FLASHINFER_CUTE_DSL_STRICT_CACHE_KEY='1',FLASHINFER_DIST_AWARE_AUTOTUNE='0',TRTLLM_ENABLE_PDL='1',FLASHINFER_DISABLE_FP4_QUANT_FAST_MATH='0',TRTLLM_DISABLE_FP4_QUANT_FAST_MATH='0',FLASHINFER_JIT_VERBOSE='0',FLASHINFER_JIT_DEBUG='0',OMP_NUM_THREADS='1',MAX_JOBS='4',PYTHONUNBUFFERED='1')
def run(command,env,name,s):
 row=dict(name=name,command=command,started=time.time(),idle=idle(),environment={k:v for k,v in env.items()if k.startswith(('CUDA_','PYTHONPATH','FLASHINFER_','CUTE_DSL_','REG_GUARD_','CODEGEN_','MEGA_'))})
 print('START',name,flush=True)
 with(OUT/f'{name}.log').open('w')as log:
  p=subprocess.Popen(command,cwd=s['repo'],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=p.wait(timeout=900)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait();row['timeout']=True
 row.update(returncode=code,finished=time.time(),stdout_sha256=sha(OUT/f'{name}.log'));receipt['runs'].append(row);save();assert code==0,row
 print('PASS',name,flush=True)
 return row
save()
try:
 recovery=OUT/'recovery-records'
 runtime=json.loads((recovery/'runtime.json').read_text());ready=json.loads((recovery/'cache-ready.json').read_text())
 assert runtime['passed'] and runtime['metadata_matches_existing'] and ready['passed']
 assert all(x['noop']for x in ready['modules'])
 readiness=json.loads((OUT/'recovery-readiness.json').read_text())
 assert readiness['passed'] and readiness['native_all_noop'] and readiness['node']=='fi-gather-pipeline-recovery-1030'
 for name in ('runtime.json','cache-ready.json','persistence.json'):assert sha(recovery/name)==readiness['records'][name]
 assert sha(ROOT/'runtime/recovery-1030/cache-ready.json')==readiness['records']['cache-ready.json']
 for module in ready['modules']:
  library=Path(module['library']);ninja=library.parent/'build.ninja'
  assert sha(library)==module['after']['library_sha256'] and sha(ninja)==module['after']['ninja_sha256']
  dry=subprocess.check_output(['ninja','-n','-C',str(library.parent)],text=True);assert 'no work to do' in dry
 receipt['recovery']={name:sha(recovery/name)for name in ('runtime.json','cache-ready.json','persistence.json')}
 receipt['recovery_readiness_sha256']=sha(OUT/'recovery-readiness.json')
 receipt['native_release_modules']=[dict(name=m['name'],library_sha256=m['after']['library_sha256'],ninja_sha256=m['after']['ninja_sha256'],noop=m['noop'])for m in ready['modules']]
 receipt['recovery_node']='fi-gather-pipeline-recovery-1030'
 receipt['physical_hostname']=subprocess.check_output(['hostname'],text=True).strip()
 verify(True);receipt.update(full_source_preflight=True,initial_idle=idle());save()
 for case in range(6):
  for role,s in sources.items():
   verify();name=f'{role}-w4a16-{case}';dest=OUT/name;dest.mkdir();(dest/'compiler-artifacts').mkdir()
   env=dict(base,CUDA_CACHE_PATH=str(ROOT/'cache/driver'),CUDA_VISIBLE_DEVICES=str(GPU),PYTHONPATH=s['repo'],FLASHINFER_WORKSPACE_BASE=s['workspace_base'],CUTE_DSL_CACHE_DIR=s['cute_cache'],FLASHINFER_JIT_BUILD_LOG=str(dest/'native-build.jsonl'),REG_GUARD_SOURCE=str(OUT/f'guard-{role}.json'),REG_GUARD_REPO=s['repo'],REG_GUARD_KERNEL_SHA=s['source_sha256']['flashinfer/fused_moe/cute_dsl/blackwell/moe_w4a16_kernel.py'],REG_GUARD_OUTPUT=str(dest/'register-guard'),REG_GUARD_CONTROL='80',REG_GUARD_GATHER='64',REG_GUARD_EPILOGUE='144',CODEGEN_OUTPUT=str(dest/'codegen'),CUTE_DSL_KEEP='ptx,cubin',CUTE_DSL_DUMP_DIR=str(dest/'compiler-artifacts'))
   cmd=[sys.executable,'-u',str(H/'capture_case.py'),'--repo',s['repo'],'--mode','w4a16','--case',str(case),'--output',str(dest/'result.json')]
   row=run(cmd,env,name,s);assert json.loads((dest/'result.json').read_text())['passed']
   cap=json.loads((dest/'codegen/receipt.json').read_text());assert cap['exitstatus']==0 and not cap['compiler_options_changed']
   kernels=[x for x in cap['kernels']if x['kind']=='Sm100W4A16GroupedGemmKernel'];assert len(kernels)==2
   assert [x['configuration']['gather_input']for x in kernels]==[True,False]
   assert all(x['native_resources']['local_bytes']==0 for x in kernels)
   expected=json.loads((OUT/'cases.json').read_text())[case]
   assert all(x['configuration']['use_clc_scheduler']==expected['clc'] and x['configuration']['enable_pdl']==expected['pdl'] and x['configuration']['use_2cta_instrs']==(expected['m']==256) for x in kernels)
   row['native_resources']=[x['native_resources']for x in kernels];save()
 verify(True);receipt.update(complete=True,passed=True,full_source_postflight=True,final_idle=idle(),finished=time.time());save()
except BaseException as e:
 receipt.update(complete=True,passed=False,error=repr(e),finished=time.time());save();raise
