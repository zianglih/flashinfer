"""Render complete primary findings without changing raw evidence or peer receipts."""
from pathlib import Path
import csv
import hashlib
import json

O = Path(__file__).resolve().parent
R = O.parents[1]
E = R / "evidence/w4-tail-cutoff-screen/1793393742504067000"
P = E / "report"
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
rows = list(csv.DictReader((P / "cells.csv").open()))
components = {(r["job"], r["tokens"]): r for r in csv.DictReader((P / "component-deltas.csv").open())}
clocks = read(P / "clock-quartiles.json")
summary = read(P / "summary.json")
resources = read(P / "resource-deltas.json")
peer = R / "audits/w4-tail-cutoff-data-peer.json"
assert summary["passed"] and resources["passed"] and read(peer)["passed"]
negative = [r for r in rows if r["retention"] == "True" and float(r["speedup_percent"]) < 0]
assert len(negative) == 8
prefix = "../../evidence/w4-tail-cutoff-screen/1793393742504067000/"
lines = [
    "# W4 transform cutoff — primary CAAC results",
    "",
    "The 39-cell primary screen is complete and independently verified. Its 33 retention cells show **+0.159%** overall: decode +0.422%, middle +0.339%, prefill −0.459%. This is not a throughput retention claim. The two strongest adverse prefill observations are being checked in one separately reported, same-GPU ACCA block; no primary row is pooled or replaced.",
    "",
    "- Source: actual immutable `2b8eb9d8` control versus only the cutoff patch `cbef9186`, still unstaged. No tactic, clock, compiler, phase/lifetime or arithmetic change.",
    "- Coverage: V41F TP4, K3 TP8 and N3U TP8 × 13 tokens; all 39 rows retained, tokens 1/2 excluded only from the 33-cell retention aggregate. CAAC, 100 CUPTI samples/phase, 10 warmups, cold-L2 CUDA graphs, fixed recorded choices/routes.",
    "- Raw replay: all 15,600 spans/156 phase medians; all 78 measured FC-stage configurations have unchanged driver resources, all 144 loaded functions LOCAL0. Five recorded defaults produce 40 actual stage/resource joins.",
    "- Clocks: 55/624 quartiles have median SM clock !=2032MHz or a nonzero reason; zero unavailable quartiles. No clocks/samples/negative cells removed. Repeat spreads describe two phase medians, not statistical confidence.",
    "- Native gate: 26 paired kernels. Four K640 FC2s remove ULEA+USHF per stage and 3 non-NOP total; K320 removes 2 total. Partial FC1 total instruction counts do not fall. One-stage compare polarity/immediate changes remain explicit; aligned/all-live/Mega paths stay raw-identical where qualified. Resources unchanged, no new occupancy claim from instruction counts.",
    "",
    f"[All 39 four-phase rows]({prefix}report/table.md) · [33-cell matrix]({prefix}report/matrix.md) · [component durations/extensions]({prefix}report/component-deltas.csv) · [all clocks]({prefix}report/clock-quartiles.json) · [independent raw peer](../../audits/w4-tail-cutoff-data-peer.md)",
    "",
    "Every negative retention row is shown below. Δ values are candidate minus control arithmetic means of the two per-phase component medians. Durations overlap under PDL; extensions indicate the component’s contribution beyond the previous end, and their separately computed medians need not sum exactly to the E2E median.",
    "",
    "| Model | Tokens | Speedup | C spread | A spread | Clock exceptions | Δ FC1 duration / extension µs | Δ FC2 duration / extension µs | Δ combine duration / extension µs |",
    "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
]
for r in negative:
    v = components[(r["job"], r["tokens"])]
    q = [q for q in clocks if q["job"] == r["job"] and q["tokens"] == int(r["tokens"])]
    exceptions = sum(q["clock"]["sm_mhz"]["median"] != 2032 or set(q["clock"]["reasons"]) != {"0"} for q in q)
    def pair(name):
        return f"{float(v['delta_' + name + '_us']):+.3f} / {float(v['delta_' + name + '_extension_us']):+.3f}"
    lines.append(f"| {r['model']} | {r['tokens']} | {float(r['speedup_percent']):+.3f}% | {float(r['control_spread_percent']):.3f}% | {float(r['candidate_spread_percent']):.3f}% | {exceptions}/16 | {pair('fc1')} | {pair('fc2')} | {pair('combine')} |")
lines += [
    "",
    "V41F TP4K and N3U TP16K each have both candidate E2E medians above both controls. Their losses are not erased by repeat-spread or clock caveats; both FC1 and FC2 durations/extensions grow in the primary record. N3U TP4K (−0.181%) and K3 TP256 (−0.021%) remain small negative observations with normal clocks and tight repeats. The remaining prefill cells retain phase drift and clock changes explicitly.",
    "",
    "The only authorized follow-up is [two-cell same-GPU ACCA](reverse-prefill/preparation.json): V41F TP4K on GPU2, N3U TP16K on GPU3, identical source/cache/routes/timing. No further repeats or matrix expansion are planned.",
]
(O / "RESULTS.md").write_text("\n".join(lines) + "\n")
receipt = dict(passed=True, primary_complete=True, retention_decision="pending separate two-cell ACCA", evidence=str((E / "data").relative_to(R)),
               candidate_kernel_sha256=read(O / "source-proof.json")["candidate_kernel_sha256"],
               measured_cells=39, retention_cells=33, samples=15600, negative_raw=sum(float(r["speedup_percent"]) < 0 for r in rows), negative_retention=len(negative),
               bindings={str(p.relative_to(R)): sha(p) for p in [P / "summary.json", P / "cells.csv", P / "component-deltas.csv", P / "clock-quartiles.json", P / "resource-deltas.json", peer, O / "RESULTS.md"]})
(O / "primary-result-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({k: v for k, v in receipt.items() if k != "bindings"}))
