"""Launch the authorized two-cell ACCA with unchanged source/cache/timing guards."""
from pathlib import Path
import base64
import gzip
import hashlib
import json
import subprocess

O = Path(__file__).resolve().parent
D = O / "reverse-prefill"
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
p = read(D / "preparation.json")
assert p["passed"] and p["config_sha256"] == sha(D / "perf-config.json")
payload = dict(config=(D / "perf-config.json").read_text(), preparation=p,
               helpers=read(O / "performance-harness-proof.json")["helpers"])
code = "PACKED=" + repr(base64.b64encode(gzip.compress(json.dumps(payload).encode())).decode()) + "\n" + r'''
from pathlib import Path
import base64,gzip,hashlib,json,platform,subprocess,time
p=json.loads(gzip.decompress(base64.b64decode(PACKED)));R=Path('/data/ziangli/flashinfer-moe-gather-pipeline');old=R/'runs/w4-tail-cutoff-screen';out=R/'runs/w4-tail-cutoff-acca';h=R/'experiments/w4-tail-cutoff/performance-harness';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not out.exists()
prep=p['preparation'];assert sha(old/'launch-preflight.json')==prep['parent_preflight_sha256']
assert sha(old/'release-postflight.json')==prep['parent_postflight_sha256']
assert sha(old/'campaign.json')==prep['primary_campaign_sha256']
pre=json.loads((old/'launch-preflight.json').read_text());assert pre['passed']
assert sha(R/'runtime/recovery-1030/cache-ready.json')==pre['cache_ready_sha256']
assert platform.node()==pre['physical_hostname']
c=json.loads(p['config']);assert hashlib.sha256(p['config'].encode()).hexdigest()==prep['config_sha256']
for n,d in p['helpers'].items():assert sha(h/n)==d
for src in c['sources'].values():
 assert sha(src['freeze_receipt'])==src['freeze_receipt_sha256'] and sha(src['tracked_manifest'])==src['tracked_manifest_sha256']
 for n,d in src['source_sha256'].items():assert sha(Path(src['repo'])/n)==d
for m in pre['native_modules']:
 assert sha(m['library'])==m['library_sha256'] and sha(Path(m['library']).parent/'build.ninja')==m['ninja_sha256']
 dry=subprocess.check_output(['ninja','-n','-C',str(Path(m['library']).parent)],text=True);assert 'no work to do' in dry
idle=[]
for name,gpu in zip(c['jobs'],prep['original_gpu_order']):
 binding=prep['original_jobs'][name];assert binding['gpu']==gpu
 assert sha(old/'results'/name/'receipt.json')==binding['receipt_sha256']
 line=subprocess.check_output(['nvidia-smi','-i',str(gpu),'--query-gpu=uuid,memory.used,utilization.gpu','--format=csv,noheader,nounits'],text=True).strip();u,m,v=[x.strip()for x in line.split(',')]
 apps=subprocess.check_output(['nvidia-smi','-i',str(gpu),'--query-compute-apps=pid','--format=csv,noheader'],text=True).strip();assert int(m)==int(v)==0 and not apps
 assert u==binding['gpu_initial'].split(',')[0]
 idle.append(dict(job=name,gpu=gpu,uuid=u,memory_mib=int(m),utilization_percent=int(v),compute_pids=apps))
out.mkdir()
def write(n,v):(out/n).write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
(out/'perf-config.json').write_text(p['config'])
for name in ('control-tracked.json','candidate-tracked.json','source-control.json','source-candidate.json','qualification-summary.json','mega-qualification-summary.json','source-proof.json'):(out/name).write_bytes((old/name).read_bytes())
write('preparation.json',prep)
cmd=[c['python'],'-u',str(h/'campaign.py'),'--config',str(out/'perf-config.json'),'--gpus',*[str(v)for v in prep['original_gpu_order']]]
preflight=dict(passed=True,time=time.time(),config_sha256=sha(out/'perf-config.json'),parent_preflight_sha256=prep['parent_preflight_sha256'],parent_postflight_sha256=prep['parent_postflight_sha256'],native_modules=pre['native_modules'],idle=idle,command=cmd)
write('launch-preflight.json',preflight)
with(out/'controller.log').open('x')as log:proc=subprocess.Popen(cmd,cwd=out,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
launch=dict(passed=True,pid=proc.pid,started=time.time(),config_sha256=sha(out/'perf-config.json'),launch_preflight_sha256=sha(out/'launch-preflight.json'),gpus=prep['original_gpu_order'],jobs=2,cells=2,samples=800,command=cmd)
write('launch.json',launch);print(json.dumps(dict(launch=launch,preflight=preflight)))
'''
compile(code, "launch_acca.remote.py", "exec")
(D / "launch.remote.py").write_text(code)
assert subprocess.check_output(["/bin/zsh", "-c", "export PATH=/usr/local/bin:$PATH; command -v h"], text=True).strip() == "/usr/local/bin/h"
x = subprocess.run(["/usr/local/bin/h", "ssh", "fi-gather-pipeline-recovery-1030", "-c", "c2", "-n", "ziangli", "--", "python3", "-c", code], cwd="/Users/ziangli/playground/repos/hai", capture_output=True, text=True)
(D / "launch.stdout").write_text(x.stdout)
(D / "launch.stderr").write_text(x.stderr)
assert x.returncode == 0, x.stderr[-3000:]
v = json.loads(x.stdout)
for k, n in [("launch", "launch.json"), ("preflight", "launch-preflight.json")]:
    (D / n).write_text(json.dumps(v[k], sort_keys=True, indent=2) + "\n")
print(json.dumps(v["launch"], indent=2))
