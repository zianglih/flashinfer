"""Replay actual captured codegen pairs; no device work or changes to raw evidence."""
from pathlib import Path
from collections import Counter
import argparse,hashlib,json,re
p=argparse.ArgumentParser();p.add_argument('--control',type=Path,required=True);p.add_argument('--candidate',type=Path);p.add_argument('--out',type=Path,required=True);a=p.parse_args();C=a.control;A=a.candidate or C
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_text())
def parse(path):
 rows=[]
 for line in path.read_text().splitlines():
  m=re.match(r'^\s*/\*([0-9a-fA-F]+)\*/\s*(.*?)\s*$',line)
  if not m:continue
  body=m[2].split('/*',1)[0].strip()
  if not body:continue
  assert body.endswith(';'),line
  op=re.match(r'^(?:@!?U?P\w+\s+)?([A-Za-z][A-Za-z0-9_.]*)(?=[\s;])',body);assert op,line
  rows.append(dict(address=m[1],opcode=op[1],instruction=body))
 assert rows,path
 return rows
old_cases=load(C/'cases.json');cases=load(A/'cases.json');assert old_cases==cases[:len(old_cases)]
receipts={}
for root in {C,A}:
 r=load(root/'receipt.json');assert r['complete'] and r['passed'] and r['full_source_preflight'] and r['full_source_postflight']
 for role,h in r['source_hashes'].items():assert sha(root/f'source-{role}.json')==h
 for n,h in r['helpers'].items():assert sha(root/'helpers'/n)==h
 for run in r['runs']:assert run['returncode']==0 and sha(root/(run['name']+'.log'))==run['stdout_sha256']
 receipts[str(root)]=sha(root/'receipt.json')
rows=[]
selected=[i for i in range(len(cases)) if (A/f'candidate-w4a16-{i}').is_dir()]
assert selected
for i in selected:
 case=cases[i];caps={}
 for role,root in [('control', C if i<len(old_cases) else A),('candidate',A)]:
  d=root/f'{role}-w4a16-{i}';r=load(d/'result.json');assert r['passed'] and r['case']==case
  c=load(d/'codegen/receipt.json');assert c['exitstatus']==0 and c['compiler_options_changed'] is False;assert len(c['kernels'])==3
  for k in c['kernels']:
   for ext in ('cubin','ptx','sass'):assert sha(d/'codegen'/(k['stem']+'.'+ext))==k[ext+'_sha256']
   assert k['native_resources']['local_bytes']==0
  caps[role]=(d,c['kernels'])
 for stage,(c,b)in enumerate(zip(caps['control'][1],caps['candidate'][1],strict=True)):
  assert c['kind']==b['kind'] and c['configuration']==b['configuration'] and c['compile_options']==b['compile_options']
  counts={};hashes={}
  for role,k in [('control',c),('candidate',b)]:
   counts[role]=Counter(x['opcode']for x in parse(caps[role][0]/'codegen'/(k['stem']+'.sass')));hashes[role]={ext:k[ext+'_sha256']for ext in ('ptx','cubin','sass')}
  raw_equal={ext:hashes['control'][ext]==hashes['candidate'][ext]for ext in hashes['control']}
  if stage==2:assert all(raw_equal.values())
  rows.append(dict(case=i,stage=stage,specification=case,configuration=c['configuration'],output_stages=c['configuration'].get('num_c_stage'),resources={role:k['native_resources']for role,k in [('control',c),('candidate',b)]},resources_equal=c['native_resources']==b['native_resources'],hashes=hashes,raw_equal=raw_equal,opcode_counts={r:dict(n)for r,n in counts.items()},non_nop={r:sum(n.values())-n['NOP']for r,n in counts.items()},opcode_delta={op:counts['candidate'][op]-counts['control'][op]for op in sorted(set(counts['candidate'])|set(counts['control']))if counts['candidate'][op]!=counts['control'][op]}))
report=dict(passed=True,source_head='2b8eb9d8f72ceda3952fbb05054fee97173fc9c7',sources={r:load(root/f'source-{r}.json')['source_sha256']['flashinfer/fused_moe/cute_dsl/blackwell/moe_w4a16_kernel.py']for r,root in [('control',C),('candidate',A)]},receipts=receipts,new_exact_calls=len(load(A/'receipt.json')['runs']),reused_control_calls=sum(i<len(old_cases) for i in selected),native_pairs=len(rows),native_output_depths=sorted({r['output_stages']for r in rows if r['output_stages']is not None}),all_local_zero=True,all_resources_equal=all(r['resources_equal']for r in rows),rows=rows,boundary='No timing. Paired existing exact calls with actual returned PTX/ELF/SASS. Candidate only hoists the per-group K-stage cutoff; retained controls are reused after explicit source/native-release cohort match. All requested/actual geometry and compiler options are matched.')
a.out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='rows'},indent=2))
for r in rows:
 if r['stage']<2:print(r['case'],r['stage'],'stages',r['output_stages'],r['non_nop'],r['opcode_delta'])
