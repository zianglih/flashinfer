from pathlib import Path
import hashlib,json
O=Path(__file__).resolve().parent;R=O.parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text())
a=read(O/'pilot-summary.json');b=read(O/'extra-summary.json');mega=read(O/'mega-qualification/qualification-summary.json')
assert all(s['passed'] and s['all_local_zero'] and s['all_resources_equal']for s in (a,b))
assert a['sources']==b['sources'] and mega['candidate_kernel_sha256']==a['sources']['candidate']
assert mega['passed'] and mega['ptx_cubin_sass_byte_identical'] and not mega['compiler_options_changed'] and mega['local_bytes']==0
rows=sorted(a['rows']+b['rows'],key=lambda r:(r['case'],r['stage']));assert len(rows)==24 and len({(r['case'],r['stage'])for r in rows})==24
assert {r['case']for r in rows}==set(range(8))
for r in rows:
 assert r['resources_equal']
 if r['case'] in (0,3) or r['stage']==2 or (r['case']==7 and r['stage']==1):assert all(r['raw_equal'].values())
 if r['case'] in (6,7) and r['stage']==0:assert r['opcode_delta']=={} and r['non_nop']['candidate']==r['non_nop']['control']
 if r['case'] in (1,2,4,5) and r['stage']==1:assert r['opcode_delta']['ULEA']==r['opcode_delta']['USHF.L.U32']==-1 and r['non_nop']['candidate']-r['non_nop']['control']==-3
 if r['case'] in (1,2,4,5) and r['stage']==0:assert r['opcode_delta']['ULEA']==-1 and r['non_nop']['candidate']==r['non_nop']['control']
 if r['case']==6 and r['stage']==1:assert r['opcode_delta']['ULEA']==-1 and r['non_nop']['candidate']-r['non_nop']['control']==-2
leaves={'pilot':O/'qualification/evidence/1793392766283766000/data','extra':O/'qualification-extra/evidence/1793393145401734000/data'}
receipts={};captures=[]
for tag,p in leaves.items():
 x=read(p/'receipt.json');assert x['complete'] and x['passed'] and x['full_source_preflight'] and x['full_source_postflight'];receipts[tag]=sha(p/'receipt.json')
 for run in x['runs']:assert run['returncode']==0 and sha(p/(run['name']+'.log'))==run['stdout_sha256']
old=R/'experiments/w4-raw-peek/qualification/evidence/1793386426136276000/data';oldrec=read(old/'receipt.json')
assert oldrec['native_release_modules']==read(leaves['pilot']/'receipt.json')['native_release_modules']==read(leaves['extra']/'receipt.json')['native_release_modules']
for case in range(8):
 for role in ('control','candidate'):
  base=old if role=='control' and case<6 else leaves['pilot' if case<2 else 'extra']
  p=base/f'{role}-w4a16-{case}';cap=read(p/'codegen/receipt.json')
  assert read(p/'result.json')['passed']
  captures.append(dict(case=case,role=role,leaf=('experiments/w4-raw-peek/qualification' if base==old else 'experiments/w4-tail-cutoff/qualification' if base==leaves['pilot'] else 'experiments/w4-tail-cutoff/qualification-extra')+'/'+p.name,result_sha256=sha(p/'result.json'),codegen_receipt_sha256=sha(p/'codegen/receipt.json')))
result=dict(passed=True,sources=a['sources'],head=a['source_head'],new_exact_calls=14,reused_control_exact_calls=6,split_cases=8,split_native_pairs=24,mega_native_pairs=2,native_pairs=26,all_local_zero=True,all_resources_equal=True,unchanged_shared_allocation_and_launch=True,occupancy_boundary='Identical registers/max_threads/local/static-shared plus unchanged source allocation/launch geometry. No new occupancy probe was introduced.',receipts={**receipts,'reused_control':sha(old/'receipt.json'),'mega':mega['receipt_sha256']},captures=captures,files={n:sha(O/n)for n in ('pilot-summary.json','extra-summary.json','source-proof.json','mega-qualification/qualification-summary.json')},changed_native_pairs=sum(not r['raw_equal']['cubin']for r in rows),raw_identical_split_pairs=sum(r['raw_equal']['cubin']for r in rows),short_tail_boundary='H128 FC1 keeps identical opcode counts; only comparison immediate0→1 and paired branch polarity change in each native SASS. No per-stage arithmetic existed for this one-stage specialization.',raw_identical_mega_pairs=2,rows=rows,boundary='CPU/source and existing exact/native qualification only. Six matched2b8 controls reused from the same release library cohort; all other14 exact calls fresh. Candidate source cbef. No performance or retention claim.')
(O/'qualification-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in ('rows','captures','files')},indent=2));print('summary_sha256',sha(O/'qualification-summary.json'))
