"""Prepare the existing affected39-cell CAAC subset locally; no deploy or timing."""
from pathlib import Path
import hashlib,json,shutil
O=Path(__file__).resolve().parent;R=O.parents[1];D=O/'performance-screen';D.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text())
P=R/'experiments/w4-raw-peek';Q=O/'qualification/evidence/1793392766283766000/data'
REMOTE='/data/ziangli/flashinfer-moe-gather-pipeline';RUN=REMOTE+'/runs/w4-tail-cutoff-screen';RQ=REMOTE+'/experiments/w4-tail-cutoff/qualification'
old=read(P/'performance-screen/perf-config.json');config=json.loads(json.dumps(old));full={r:read(Q/f'source-{r}.json')for r in ('control','candidate')}
proof=read(O/'source-proof.json');freeze=read(Q/'freeze.json')
K='flashinfer/fused_moe/cute_dsl/blackwell/moe_w4a16_kernel.py'
assert full['control']['source_sha256'][K]==proof['base_kernel_sha256'] and full['candidate']['source_sha256'][K]==proof['candidate_kernel_sha256']
assert all(len(s['source_sha256'])==13245 and s['head']==proof['base']for s in full.values())
assert all(sha(Q/f'source-{r}.json')==freeze['source_files'][r]for r in full)
delta={n:dict(control=d,measured=full['candidate']['source_sha256'][n])for n,d in full['control']['source_sha256'].items()if d!=full['candidate']['source_sha256'][n]};assert set(delta)=={K}
keys=('tp-v41-flash-w4a16','tp-kimi-k3-w4a16','tp-nemo3-ultra-w4a16');config['jobs']={k:old['jobs'][k]for k in keys}
config.update(label='w4-tail-cutoff-cbef-2b8',output=RUN+'/results',observer=REMOTE+'/experiments/w4-tail-cutoff/performance-harness/observe_benchmark.py',boundary='Existing39 affected W4 tail cells: V41F/K3/N3U TP,all13tokens;33 retention cells exclude1/2. Same frozen routes/choices including existing defaults,strict CUPTI100 samples,10warmups,coldL2 CUDAgraphs,sameGPU CAAC. Preserve all negatives,components,clocks and variation. No tuning,eventfallback,clock changes or sanitizer. Held pending complete split/Mega native gates and root performance approval.')
helpers=O/'performance-harness';shutil.copytree(P/'performance-harness',helpers,ignore=shutil.ignore_patterns('__pycache__'))
hp=read(P/'performance-harness-proof.json');assert all(sha(helpers/n)==d for n,d in hp['helpers'].items())
(O/'performance-harness-proof.json').write_text(json.dumps(dict(passed=True,parent='experiments/w4-raw-peek/performance-harness',parent_proof_sha256=sha(P/'performance-harness-proof.json'),helpers=hp['helpers'],all_byte_identical=True),indent=2)+'\n')
for role,s in full.items():
 tracked=D/f'{role}-tracked.json';tracked.write_text(json.dumps(s['source_sha256'],sort_keys=True,indent=2)+'\n')
 prev=old['sources'][role];owned={n:s['source_sha256'][n]for n in prev['source_sha256']}
 z=dict(prev,head=proof['base'],label='w4-tail-cutoff-'+role,repo=s['repo'],source_file=RUN+f'/source-{role}.json',source_sha256=owned,tracked_manifest=RUN+f'/{role}-tracked.json',tracked_manifest_sha256=sha(tracked),register_policy=s['register_policy'],workspace_base=s['workspace_base'],cute_cache=s['cute_cache'],freeze_receipt=RQ+f'/source-{role}.json',freeze_receipt_sha256=sha(Q/f'source-{role}.json'),control_manifest=RQ+'/source-control.json',control_manifest_sha256=sha(Q/'source-control.json'),changed_from_control={}if role=='control'else delta,identity_boundary='Actual immutable retained2b8 control by full13245-file equivalence; candidate only hoists the existing partial-K transform cutoff. Current release native cohort. No historical timing reused.')
 (D/f'source-{role}.json').write_text(json.dumps(z,sort_keys=True,indent=2)+'\n');config['sources'][role]=z
selected=[x for x in read(P/'selected-winners.json')if x['job']in keys];assert len(selected)==39
assert all(config['jobs'][k]==old['jobs'][k]for k in keys)
assert config['phases']==['control','candidate','candidate','control']
(O/'selected-winners.json').write_text(json.dumps(selected,indent=2)+'\n');(D/'perf-config.json').write_text(json.dumps(config,sort_keys=True,indent=2)+'\n')
defaults=sum(x['choice']['tactic']==-1 for x in selected)
x=dict(passed=True,held=True,launched=False,remote_written=False,config_sha256=sha(D/'perf-config.json'),jobs=3,cells=39,retention_cells=33,samples=15600,recorded_defaults=defaults,explicit_choices=39-defaults,full_source_hashes=freeze['source_files'],helpers=hp['helpers'],selected_winners_sha256=sha(O/'selected-winners.json'),parent_config_sha256=sha(P/'performance-screen/perf-config.json'),unchanged_jobs_routes_choices=True,qualification_pending=['remaining split native','Mega native','root performance authorization'])
(D/'preparation.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps({k:v for k,v in x.items()if k!='helpers'}))
