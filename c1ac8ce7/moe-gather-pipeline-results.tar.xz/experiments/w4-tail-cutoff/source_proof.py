#!/usr/bin/env python3
"""CPU-only proof of the retained K-tail predicate's invariant cutoff form."""

import ast
import copy
import hashlib
import json
import pathlib
import re
import subprocess
from types import SimpleNamespace

ROOT = pathlib.Path(__file__).resolve().parents[2]
REVIEW = ROOT / "flashinfer-w4-tail-cutoff-review"
REL = "flashinfer/fused_moe/cute_dsl/blackwell/moe_w4a16_kernel.py"
BASE = "2b8eb9d8f72ceda3952fbb05054fee97173fc9c7"
OUT = pathlib.Path(__file__).resolve().parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


def method(tree):
    return next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)
                and n.name == "_transform_tile")


def dump(node):
    return ast.dump(node, include_attributes=False)


def expr(node):
    return compile(ast.Expression(node), "<source-expression>", "eval")


def main():
    base = subprocess.check_output(["git", "show", f"{BASE}:{REL}"], cwd=REVIEW)
    candidate = (REVIEW / REL).read_bytes()
    old, new = ast.parse(base), ast.parse(candidate)
    old_fn, new_fn = method(old), method(new)
    old_loop = next(n for n in old_fn.body if isinstance(n, ast.For))
    new_loop = next(n for n in new_fn.body if isinstance(n, ast.For))
    old_guard = next(n for n in old_loop.body if isinstance(n, ast.If)
                     and "tail_k" in ast.unparse(n.test))
    new_guard = next(n for n in new_loop.body if isinstance(n, ast.If)
                     and "tail_k" in ast.unparse(n.test))
    setup_guard = new_fn.body[4]
    assert isinstance(setup_guard, ast.If)
    assert dump(old_guard.test) == dump(new_guard.test) == dump(setup_guard.test)
    assert ast.unparse(new_fn.body[3]) == "transform_k_tiles = k_tile_cnt"
    assert ast.unparse(new_guard.body[0]) == "transform_valid = _k_tile < transform_k_tiles"
    cutoff = setup_guard.body[0].value
    assert ast.unparse(cutoff) == (
        "k_tile_cnt - cutlass.Int32(transform_group_idx >= cute.ceil_div(tail_k, group_k))"
    )

    # Reversing only the setup relocation and predicate substitution restores the
    # complete original module, including every pipeline/state/store operation.
    inverse = copy.deepcopy(new)
    fn = method(inverse)
    setup = fn.body[1:5]
    del fn.body[1:5]
    loop = next(n for n in fn.body if isinstance(n, ast.For))
    idx = next(i for i, n in enumerate(loop.body) if isinstance(n, ast.If)
               and "tail_k" in ast.unparse(n.test))
    loop.body[idx:idx + 1] = [setup[0], setup[1], copy.deepcopy(old_guard)]
    assert dump(inverse) == dump(old)

    ceil_div = lambda a, b: (a + b - 1) // b
    env = {"cute": SimpleNamespace(ceil_div=ceil_div),
           "cutlass": SimpleNamespace(Int32=int)}
    old_expr = expr(old_guard.body[0].value)
    new_expr = expr(new_guard.body[0].value)
    cutoff_expr = expr(cutoff)
    guard_expr = expr(old_guard.test.args[0])
    comparisons = affected = elided = 0
    for groups in (1, 2, 3, 4, 8):
        for group_k in (16, 32, 64, 128, 256):
            stage_k = groups * group_k
            env["self"] = SimpleNamespace(mma_tiler=(128, 16, stage_k))
            for full_tiles in range(8):
                for tail_k in range(stage_k):
                    consumed_k = full_tiles * stage_k + tail_k
                    if consumed_k == 0:
                        continue
                    count = ceil_div(consumed_k, stage_k)
                    env.update(group_k=group_k, tail_k=tail_k,
                               consumed_k=consumed_k, k_tile_cnt=count)
                    guarded = eval(guard_expr, env)
                    for group in range(groups):
                        env["transform_group_idx"] = group
                        env["transform_k_tiles"] = eval(cutoff_expr, env) if guarded else count
                        for tile in range(count):
                            env["_k_tile"] = tile
                            before = eval(old_expr, env) if guarded else True
                            after = eval(new_expr, env) if guarded else True
                            assert before == after
                            assert after or tile == count - 1
                            comparisons += 1
                            affected += int(guarded)
                            elided += int(not guarded)

    captures = ROOT / "experiments/w4-raw-peek/qualification/evidence/1793386426136276000/data"
    native = []
    for case in (1, 2, 4, 5):
        leaf = captures / f"control-w4a16-{case}"
        receipt = json.loads((leaf / "codegen/receipt.json").read_text())
        k = receipt["kernels"][1]
        ptx = leaf / "codegen" / (k["stem"] + ".ptx")
        sass = leaf / "codegen" / (k["stem"] + ".sass")
        assert sha(ptx.read_bytes()) == k["ptx_sha256"]
        assert sha(sass.read_bytes()) == k["sass_sha256"]
        instructions = []
        for line in sass.read_text().splitlines():
            m = re.match(r"\s*/\*([0-9a-f]+)\*/\s+(.*?;)", line)
            if m:
                instructions.append({"pc": "0x" + m[1], "instruction": m[2]})
        ix = [i for i, row in enumerate(instructions)
              if "UISETP.GT.U32" in row["instruction"] and ", 0x27f, " in row["instruction"]]
        assert len(ix) == 1
        window = instructions[ix[0] - 2:ix[0] + 2]
        assert window[0]["instruction"].startswith("ULEA ")
        assert window[1]["instruction"].startswith("USHF.L.U32 ")
        assert window[3]["instruction"].startswith("BRA.U ")
        guards = list((leaf / "register-guard").glob("*/receipt.json"))
        assert len(guards) == 1
        g = json.loads(guards[0].read_text())
        assert g["kernel_sha256"] == sha(base)
        assert g["all_guarded"] and not g["compiler_options_changed"]
        native.append({"case": case, "consumed_k": 640, "kernel": "FC2",
                       "configuration": k["configuration"], "resources": k["native_resources"],
                       "ptx": str(ptx.relative_to(ROOT)), "ptx_sha256": sha(ptx.read_bytes()),
                       "sass": str(sass.relative_to(ROOT)), "sass_sha256": sha(sass.read_bytes()),
                       "cubin_sha256": k["cubin_sha256"], "window": window})

    result = {"passed": True, "base": BASE, "base_kernel_sha256": sha(base),
              "candidate_kernel_sha256": sha(candidate), "source_file": REL,
              "inverse_whole_module_ast_equal": True,
              "algebra": {"comparisons": comparisons, "guarded": affected,
                          "constexpr_elided": elided, "group_counts": [1, 2, 3, 4, 8],
                          "group_k": [16, 32, 64, 128, 256], "full_tiles": "0..7"},
              "baseline_native_evidence": native,
              "unchanged": ["function signature", "both transform_valid uses", "raw/decoded waits",
                            "pipeline advances/releases/arrivals", "TMEM stores", "iKET scopes",
                            "full-K/all-live-tail constexpr elision", "Mega padded-K specialization"],
              "boundary": "CPU source/algebra and retained native inspection only. Candidate codegen, resources, exact numerics and performance untested."}
    (OUT / "source-proof.json").write_text(json.dumps(result, indent=2) + "\n")
    (OUT / "candidate-kernel.py.txt").write_bytes(candidate)
    (OUT / "candidate.patch").write_bytes(subprocess.check_output(["git", "diff", "--", REL], cwd=REVIEW))
    print(json.dumps({"passed": True, "candidate_sha256": sha(candidate), "comparisons": comparisons,
                      "source_proof_sha256": sha((OUT / "source-proof.json").read_bytes())}))


if __name__ == "__main__":
    main()
