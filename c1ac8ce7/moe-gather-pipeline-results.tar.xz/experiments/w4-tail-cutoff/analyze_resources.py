"""Compare actual loaded W4 configurations/resources in paired timing phases."""

import argparse
import hashlib
import json
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("evidence", type=Path)
a = p.parse_args()
root = a.evidence.resolve()
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
config = read(root / "perf-config.json")
fetch = read(root.parent / "fetch-receipt.json")
records = {}
loaded = 0
for job in fetch["jobs"]:
    folder = root / "results" / job
    receipt = read(folder / "receipt.json")
    assert receipt["complete"] and receipt["config_sha256"] == sha(root / "perf-config.json")
    for phase in receipt["phases"]:
        label = f"{phase['index']}-{phase['role']}"
        libraries = {}
        for entry in phase["register_guards"]:
            path = folder / Path(entry["path"]).relative_to(Path(config["output"]) / job)
            assert sha(path) == entry["sha256"]
            for fn in read(path)["compilations"]:
                assert fn["analysis"]["local_bytes"] == 0
                libraries[fn["library_handle"]] = fn
                loaded += 1
        result = read(folder / label / "results.json")
        measurements = iter(result["native_diagnostic"]["measurements"])
        for row in result["rows"]:
            for output in row["results"]:
                measured = next(measurements)
                for resolved in measured["w4_resolved_configs"]:
                    fn = libraries[resolved["compiled_library"]]
                    record = dict(fn["analysis"])
                    for name in ("gather_input", "mma_tiler_mnk", "cluster_shape_mn",
                                 "raster_along_m", "use_clc_scheduler", "enable_pdl",
                                 "compile_options"):
                        record[name] = fn[name]
                    key = (job, row["tokens"], output["backend"], resolved["stage"])
                    assert label not in records.setdefault(key, {})
                    records[key][label] = record
        assert next(measurements, None) is None
rows = []
expected_phases = {f"{i}-{role}" for i, role in enumerate(config["phases"])}
control_phase = next(f"{i}-{role}" for i, role in enumerate(config["phases"]) if role == "control")
for key, phases in records.items():
    assert set(phases) == expected_phases
    equal = all(v == phases[control_phase] for v in phases.values())
    rows.append(dict(job=key[0], tokens=key[1], backend=key[2], stage=key[3],
                     resources_equal=equal, phases=phases))
summary = dict(passed=True, config_sha256=sha(root / "perf-config.json"),
               loaded_kernel_records=loaded, cell_stage_records=len(rows),
               all_resources_equal=all(r["resources_equal"] for r in rows),
               changed=[r for r in rows if not r["resources_equal"]], rows=rows,
               boundary="Actual CUDA driver attributes joined to measured stage via the compiled library handle. This is not a claim of timed cubin identity. No timing or sample modifications.")
out = root.parent / "report" / "resource-deltas.json"
out.write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps({k: v for k, v in summary.items() if k != "rows"}, indent=2))
