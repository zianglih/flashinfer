"""Prepare only the two parent-authorized reverse-order cells; primary39 stays intact."""
from pathlib import Path
import copy
import hashlib
import json

O = Path(__file__).resolve().parent
R = O.parents[1]
D = O / "reverse-prefill"
D.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
primary = R / "evidence/w4-tail-cutoff-screen/1793393742504067000/data"
old = read(O / "performance-screen/perf-config.json")
c = copy.deepcopy(old)
c.update(
    label="w4-tail-cutoff-prefill-acca",
    output="/data/ziangli/flashinfer-moe-gather-pipeline/runs/w4-tail-cutoff-acca/results",
    phases=["candidate", "control", "control", "candidate"],
    boundary="Separate same-GPU ACCA diagnostic for V41F TP4 T4096 and N3U TP8 T16384 only. Same immutable2b8/cbef sources, release libraries, recorded choices/routes, strict CUPTI100 samples/10warmups/coldL2 CUDAgraphs. Primary39 CAAC is preserved without pooling or replacement. No clock changes, retuning or further repeats.",
)
targets = {"tp-nemo3-ultra-w4a16": 16384, "tp-v41-flash-w4a16": 4096}
c["jobs"] = {}
bindings = {}
for name, tokens in targets.items():
    c["jobs"][name] = dict(old["jobs"][name], tokens=[tokens], expected_cells=1)
    p = primary / "results" / name / "receipt.json"
    r = read(p)
    assert r["complete"] and all(v["verified"] for v in r["phases"])
    bindings[name] = dict(gpu=r["gpu"], gpu_initial=r["gpu_initial"], receipt_sha256=sha(p), tokens=tokens)
inverse = copy.deepcopy(c)
for key in ("label", "output", "phases", "boundary", "jobs"):
    inverse[key] = old[key]
assert inverse == old and c["sources"] == old["sources"]
assert [bindings[k]["gpu"] for k in sorted(targets)] == [3, 2]
(D / "perf-config.json").write_text(json.dumps(c, sort_keys=True, indent=2) + "\n")
prep = dict(passed=True, parent_config_sha256=sha(O / "performance-screen/perf-config.json"), config_sha256=sha(D / "perf-config.json"),
            jobs=2, cells=2, phases=4, samples=800, primary_evidence=str(primary.relative_to(R)),
            primary_campaign_sha256=sha(primary / "campaign.json"), original_jobs=bindings,
            original_gpu_order=[3, 2], source_and_helper_contract_unchanged=True,
            allowed_changes=["label", "output", "boundary", "phase order", "two existing job/token subsets"],
            parent_preflight_sha256=sha(primary / "launch-preflight.json"),
            parent_postflight_sha256=sha(O / "performance-screen/gpu-release.json"))
(D / "preparation.json").write_text(json.dumps(prep, indent=2) + "\n")
print(json.dumps(prep, indent=2))
