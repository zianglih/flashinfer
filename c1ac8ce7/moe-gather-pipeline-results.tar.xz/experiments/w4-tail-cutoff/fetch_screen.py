"""Snapshot only completed benchmark jobs, preserving remote evidence and caches."""

import argparse
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import tarfile
import time

PROJECT = Path(__file__).resolve().parents[2]
REMOTE = "/data/ziangli/flashinfer-moe-gather-pipeline"
HAI = "/Users/ziangli/playground/repos/hai"


def ssh(script, **kwargs):
    return subprocess.run(
        ["/usr/local/bin/h", "ssh", NODE, "-c", "c2", "-n", "ziangli",
         "--", "bash", "-lc", script], cwd=HAI, check=True, **kwargs
    )


def download(receipt, archive):
    # Large Kubernetes stdout streams can terminate early with exit status zero.
    # Bound each transfer and verify it before adding it to the final archive.
    with archive.open("wb") as stream:
        for chunk in receipt["archive_chunks"]:
            code = "import sys; f=open(" + repr(receipt["archive"]) + ", 'rb'); f.seek(" + str(chunk["offset"]) + "); sys.stdout.buffer.write(f.read(" + str(chunk["size"]) + "))"
            data = ssh("python3 -c " + shlex.quote(code), capture_output=True).stdout
            assert len(data) == chunk["size"] and hashlib.sha256(data).hexdigest() == chunk["sha256"]
            stream.write(data)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--node", required=True, choices=["fi-gather-pipeline-recovery-1030"])
    p.add_argument("run")
    a = p.parse_args()
    global NODE
    NODE = a.node
    assert a.run and all(x.isalnum() or x in "-_" for x in a.run)
    stamp = str(time.time_ns())
    out = PROJECT / "evidence" / a.run / stamp
    out.mkdir(parents=True, exist_ok=False)
    code = '''
from pathlib import Path
import json,hashlib,tarfile,time,io
base=Path(REMOTE);run=base/'runs'/RUN
selected=[];jobs=[]
for path in sorted(run.glob('results/*/receipt.json')):
    data=json.loads(path.read_text())
    if not data.get('complete'):continue
    assert all(x.get('verified') and x['returncode']==0 for x in data['phases'])
    analysis=path.parent/'analysis.json'
    if not analysis.exists():continue
    try: analyzed=json.loads(analysis.read_text())
    except json.JSONDecodeError:continue
    if not analyzed.get('complete') or analyzed['receipt_sha256']!=hashlib.sha256(path.read_bytes()).hexdigest():continue
    jobs.append(path.parent.name)
    for f in sorted(path.parent.rglob('*')):
        relative=f.relative_to(path.parent)
        if any(x.startswith(('cache-','triton')) for x in relative.parts):continue
        if f.is_file():selected.append(f)
for f in sorted(run.glob('*')):
    if f.is_file():selected.append(f)
archive=base/'evidence-bundles'/(RUN+'-'+STAMP+'.tar.gz');archive.parent.mkdir(exist_ok=True)
manifest={}
with tarfile.open(archive,'w:gz') as tar:
    for f in selected:
        content=f.read_bytes();name=str(f.relative_to(run))
        manifest[name]=hashlib.sha256(content).hexdigest()
        info=tarfile.TarInfo(name);info.size=len(content)
        tar.addfile(info,io.BytesIO(content))
chunks=[]
with archive.open('rb') as stream:
    while content:=stream.read(16*1024*1024):
        chunks.append(dict(offset=stream.tell()-len(content),size=len(content),sha256=hashlib.sha256(content).hexdigest()))
receipt=dict(run=RUN,jobs=jobs,archive=str(archive),archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),archive_chunks=chunks,files=manifest,time=time.time(),boundary='Only fully qualified completed jobs. All phase data included; reproducible cache/triton directories excluded. Original remote evidence untouched.')
print(json.dumps(receipt))
'''.replace("REMOTE", repr(REMOTE)).replace("RUN", repr(a.run)).replace("STAMP", repr(stamp))
    result = ssh("python3 -c " + shlex.quote(code), text=True, capture_output=True)
    receipt = json.loads(result.stdout)
    receipt["transport_node"] = NODE
    (out / "remote-fetch-record.json").write_text(json.dumps(receipt, indent=2) + "\n")
    archive = out / "evidence.tar.gz"
    download(receipt, archive)
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == receipt["archive_sha256"]
    data = out / "data"
    data.mkdir()
    with tarfile.open(archive) as tar:
        for member in tar.getmembers():
            assert member.isfile() and not Path(member.name).is_absolute() and ".." not in Path(member.name).parts
        tar.extractall(data, filter="data")
    for relative, digest in receipt["files"].items():
        assert hashlib.sha256((data / relative).read_bytes()).hexdigest() == digest, relative
    receipt.update(local=str(data), passed=True)
    (out / "fetch-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(dict(local=str(data), jobs=receipt["jobs"], files=len(receipt["files"]), archive_sha256=receipt["archive_sha256"])))


if __name__ == "__main__":
    main()
