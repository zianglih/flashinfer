"""Four existing Mega exact calls and passive native capture; GPU3 only."""
from pathlib import Path
import hashlib, json, os, signal, subprocess, sys, time

ROOT = Path('/data/ziangli/flashinfer-moe-gather-pipeline')
OUT = ROOT / 'experiments/w4-tail-cutoff/mega-qualification'
GPU = 3
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
sources = {arm: json.loads((OUT / f'source-{arm}.json').read_text()) for arm in ('control', 'candidate')}
receipt = dict(started=time.time(), complete=False, passed=False, gpu=GPU, runs=[],
               source_hashes={a: sha(OUT / f'source-{a}.json') for a in sources},
               helper_hashes={p.name: sha(p) for p in OUT.glob('*.py')},
               boundary='Existing single-rank zero-tolerance Mega helper, same compiler options; no timing, sanitizer, tuning or production instrumentation.')
assert not (OUT / 'receipt.json').exists()

def save():
    (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')

def verify():
    for arm, source in sources.items():
        assert source['head'] == '2b8eb9d8f72ceda3952fbb05054fee97173fc9c7'
        assert sha(OUT / f'source-{arm}.json') == receipt['source_hashes'][arm]
        for name, digest in source['source_sha256'].items():
            assert sha(Path(source['repo']) / name) == digest, (arm, name)

def idle():
    apps = subprocess.check_output(['nvidia-smi', '-i', str(GPU), '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
    assert not apps, apps
    row = subprocess.check_output(['nvidia-smi', '-i', str(GPU), '--query-gpu=uuid,name,memory.used,utilization.gpu', '--format=csv,noheader,nounits'], text=True).strip()
    assert [x.strip() for x in row.split(',')][-2:] == ['0', '0'], row
    return row

def cache_check():
    ready_path = OUT / 'recovery-readiness.json'
    cache_path = OUT / 'recovery-cache-ready.json'
    ready, cache = json.loads(ready_path.read_text()), json.loads(cache_path.read_text())
    assert ready['passed'] and ready['node'] == 'fi-gather-pipeline-recovery-1030'
    assert cache['passed'] and sha(cache_path) == ready['records']['cache-ready.json']
    rows = []
    for module in cache['modules']:
        lib = Path(module['library']); ninja = lib.parent / 'build.ninja'
        assert sha(lib) == module['after']['library_sha256']
        assert sha(ninja) == module['after']['ninja_sha256']
        dry = subprocess.check_output(['ninja', '-n', '-C', str(lib.parent)], text=True)
        assert 'no work to do' in dry, dry
        rows.append(dict(name=module['name'], library=str(lib), library_sha256=sha(lib), ninja_sha256=sha(ninja), dryrun=dry))
    return dict(readiness_sha256=sha(ready_path), cache_ready_sha256=sha(cache_path), hostname=subprocess.check_output(['hostname'], text=True).strip(), modules=rows)

base = {k: v for k, v in os.environ.items() if not k.startswith(('FLASHINFER_', 'TRTLLM_', 'CUTE_DSL_', 'MEGA_')) and k not in ('CUDA_VISIBLE_DEVICES', 'PYTHONOPTIMIZE')}
base.update(FLASHINFER_CUDA_ARCH_LIST='10.3a', FLASHINFER_CUTE_DSL_STRICT_CACHE_KEY='1', FLASHINFER_DIST_AWARE_AUTOTUNE='0',
            FLASHINFER_JIT_VERBOSE='0', FLASHINFER_JIT_DEBUG='0', OMP_NUM_THREADS='1', MAX_JOBS='4', PYTHONUNBUFFERED='1')
save()
try:
    changed = [n for n in sources['control']['source_sha256'] if sources['control']['source_sha256'][n] != sources['candidate']['source_sha256'][n]]
    assert changed == ['flashinfer/fused_moe/cute_dsl/blackwell/moe_w4a16_kernel.py'], changed
    receipt['changed_production_files'] = changed
    receipt['cache_preflight'] = cache_check()
    verify(); receipt.update(full_source_preflight=True, initial_idle=idle()); save()
    for h, i in [(256, 256), (384, 640)]:
        for arm, source in sources.items():
            name = f'{arm}-h{h}-i{i}'; out = OUT / name
            env = dict(base, CUDA_CACHE_PATH=str(ROOT / 'cache/driver'), CUDA_VISIBLE_DEVICES=str(GPU), PYTHONPATH=source['repo'],
                       FLASHINFER_WORKSPACE_BASE=source['workspace_base'], CUTE_DSL_CACHE_DIR=source['cute_cache'],
                       CUTE_DSL_KEEP='ptx,cubin', CUTE_DSL_DUMP_DIR=str(out / 'compiler'))
            cmd = [sys.executable, '-u', str(OUT / 'capture_exact.py'), '--repo', source['repo'], '--source', str(OUT / f'source-{arm}.json'),
                   '--hidden', str(h), '--intermediate', str(i), '--output', str(out)]
            row = dict(arm=arm, hidden=h, intermediate=i, idle=idle(), started=time.time(), command=cmd,
                       environment={k: v for k, v in env.items() if k.startswith(('CUDA_', 'FLASHINFER_', 'CUTE_DSL_', 'MEGA_')) or k == 'PYTHONPATH'})
            print('START', name, flush=True)
            with (OUT / f'{name}.log').open('w') as log:
                proc = subprocess.Popen(cmd, cwd=source['repo'], env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                try:
                    code = proc.wait(timeout=900)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid, signal.SIGTERM)
                    try: code = proc.wait(timeout=15)
                    except subprocess.TimeoutExpired: os.killpg(proc.pid, signal.SIGKILL); code = proc.wait(timeout=15)
                    row['timeout'] = True
            row.update(returncode=code, finished=time.time(), stdout_sha256=sha(OUT / f'{name}.log'))
            receipt['runs'].append(row); save(); assert code == 0, row
            exact = json.loads((out / 'receipt.json').read_text()); assert exact['passed'] and exact['kernels']
            assert all(k['native_resources']['local_bytes'] == 0 for k in exact['kernels'])
            print('PASS', name, flush=True)
    verify(); receipt.update(full_source_postflight=True, cache_postflight=cache_check(), final_idle=idle(), complete=True, passed=True, finished=time.time()); save()
except BaseException as error:
    receipt.update(complete=True, passed=False, error=repr(error), finished=time.time()); save(); raise
