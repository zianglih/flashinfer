"""Strict complete-opcode/native-resource replay; never edits raw evidence."""
from pathlib import Path
from collections import Counter
import hashlib, json, re

ROOT = Path(__file__).resolve().parent
E = ROOT / 'evidence'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda p: json.loads(Path(p).read_text())
r = load(E / 'receipt.json')
assert r['complete'] and r['passed'] and r['full_source_preflight'] and r['full_source_postflight']
assert len(r['runs']) == 4 and all(x['returncode'] == 0 for x in r['runs'])
for n, h in r['helper_hashes'].items(): assert sha(E / n) == h
sources = {a: load(E / f'source-{a}.json') for a in ('control', 'candidate')}
for a in sources: assert sha(E / f'source-{a}.json') == r['source_hashes'][a]
delta = [n for n in sources['control']['source_sha256'] if sources['control']['source_sha256'][n] != sources['candidate']['source_sha256'][n]]
assert delta == ['flashinfer/fused_moe/cute_dsl/blackwell/moe_w4a16_kernel.py']

def parse_sass(text):
    rows = []
    for line in text.splitlines():
        m = re.match(r'^\s*/\*([0-9a-fA-F]+)\*/\s*(.*?)\s*$', line)
        if not m: continue
        body = m[2].split('/*', 1)[0].strip()
        if not body: continue
        assert body.endswith(';'), line
        op = re.match(r'^(?:@!?U?P\w+\s+)?([A-Za-z][A-Za-z0-9_.]*)(?=[\s;])', body)
        assert op, line
        rows.append(dict(pc=m[1], opcode=op[1], text=body))
    assert rows
    return rows

rows = []
for h, i in [(256, 256), (384, 640)]:
    pair = {}
    for arm in sources:
        d = E / f'{arm}-h{h}-i{i}'
        v = load(d / 'receipt.json')
        assert v['passed'] and not v['compiler_options_changed'] and v['source_sha256'] == r['source_hashes'][arm]
        assert len(v['kernels']) == 1
        k = v['kernels'][0]
        for ext in ('ptx', 'cubin', 'sass'): assert sha(d / (k['stem'] + '.' + ext)) == k[ext + '_sha256']
        resources = (d / (k['stem'] + '.resources.txt')).read_text()
        assert 'STACK:0' in resources and 'LOCAL:0' in resources
        assert k['native_resources']['local_bytes'] == 0 and k['native_resources']['max_threads'] >= 640
        native = parse_sass((d / (k['stem'] + '.sass')).read_text())
        counts = Counter(x['opcode'] for x in native)
        assert not any(op.startswith(('LDL', 'STL')) for op in counts)
        ptx = (d / (k['stem'] + '.ptx')).read_text()
        barrier_forms = Counter(re.findall(r'\bmbarrier\.(?:try_wait|test_wait)[.A-Za-z0-9_:]*', ptx))
        pair[arm] = dict(kernel=k, opcode_counts=dict(counts), non_nop=sum(counts.values()) - counts['NOP'],
                         barrier_forms=dict(barrier_forms), native_syncs=[x for x in native if x['opcode'].startswith('SYNCS.PHASECHK')])
    c, a = pair['control'], pair['candidate']
    assert c['kernel']['configuration'] == a['kernel']['configuration']
    assert c['kernel']['compile_options'] == a['kernel']['compile_options']
    assert c['kernel']['native_resources'] == a['kernel']['native_resources']
    assert c['kernel']['ptx_sha256'] == a['kernel']['ptx_sha256']
    assert c['kernel']['cubin_sha256'] == a['kernel']['cubin_sha256']
    assert c['kernel']['sass_sha256'] == a['kernel']['sass_sha256']
    ops = set(c['opcode_counts']) | set(a['opcode_counts'])
    rows.append(dict(hidden=h, intermediate=i, arms=pair, resources_equal=True,
                     opcode_delta={op: a['opcode_counts'].get(op, 0) - c['opcode_counts'].get(op, 0) for op in sorted(ops) if a['opcode_counts'].get(op, 0) != c['opcode_counts'].get(op, 0)}))
report = dict(passed=True, exact_calls=4, native_pairs=2, source_delta=delta, receipt_sha256=sha(E / 'receipt.json'),
              source_hashes=r['source_hashes'], rows=rows,
              boundary='Four existing single-rank exact calls; actual native code/resources. Mega passes padded consumed K; both actual specializations must be byte-identical. No distributed race, timing or sanitizer claim.')
(ROOT / 'native-summary.json').write_text(json.dumps(report, indent=2) + '\n')
for row in rows:
    print(row['hidden'], row['intermediate'], {a: v['non_nop'] for a, v in row['arms'].items()}, row['opcode_delta'])
