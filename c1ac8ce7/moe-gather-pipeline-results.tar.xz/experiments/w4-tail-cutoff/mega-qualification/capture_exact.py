"""Existing single-rank MegaMoE exact helper plus passive native capture."""
import argparse,hashlib,json,os,subprocess,sys,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--source',type=Path,required=True);p.add_argument('--hidden',type=int,required=True);p.add_argument('--intermediate',type=int,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
sys.path.insert(0,str(a.repo))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=json.loads(a.source.read_text());assert source['head']=='2b8eb9d8f72ceda3952fbb05054fee97173fc9c7' and Path(source['repo'])==a.repo
scope=[n for n in source['source_sha256'] if n.startswith(('flashinfer/moe_ep/cute_dsl/megamoe/bf16_nvfp4/','flashinfer/fused_moe/cute_dsl/blackwell/')) and n.endswith('.py')]+['tests/moe_ep/test_nvfp4_cutedsl_kernel_vs_reference.py','tests/test_helpers/w4a16_reference.py']
def verify():
 for name in scope:assert sha(a.repo/name)==source['source_sha256'][name],name
verify();a.output.mkdir(exist_ok=False);(a.output/'compiler').mkdir()
assert os.environ['CUTE_DSL_KEEP']=='ptx,cubin'
import pytest,torch,cutlass.cute as cute,cuda.bindings.driver as cuda,flashinfer
assert Path(flashinfer.__file__).resolve().is_relative_to(a.repo)
from tests.moe_ep.test_nvfp4_cutedsl_kernel_vs_reference import _check_nvfp4_kernel_matches_torch_reference
receipt=dict(started=time.time(),hidden=a.hidden,intermediate=a.intermediate,world_size=1,source_sha256=sha(a.source),compiler_options_changed=False,source_files_checked=scope,kernels=[],passed=False,boundary='Existing single-rank MegaMoE exact helper with MEGA_NO_DIST=1. Passive capture of the actual returned compiled library, no timing, new tuning, sanitizer or kernel instrumentation.')
def save():(a.output/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
def checked(v):
 assert v[0]==cuda.CUresult.CUDA_SUCCESS,v
 return v[1] if len(v)==2 else v[1:]
original=cute.compile
def compile(*args,**kwargs):
 owner=getattr(args[0],'__self__',args[0]);compiled=original(*args,**kwargs)
 if type(owner).__name__!='Sm100W4A16MegaMoEKernel':return compiled
 library=cuda.CUlibrary(int(compiled.library));device=checked(cuda.cuCtxGetDevice());count=int(checked(cuda.cuLibraryGetKernelCount(library)));assert count==1
 handle=checked(cuda.cuLibraryEnumerateKernels(count,library))[0]
 native={key:int(checked(cuda.cuKernelGetAttribute(getattr(cuda.CUfunction_attribute,'CU_FUNC_ATTRIBUTE_'+attr),handle,device))) for key,attr in [('registers','NUM_REGS'),('max_threads','MAX_THREADS_PER_BLOCK'),('local_bytes','LOCAL_SIZE_BYTES'),('shared_bytes','SHARED_SIZE_BYTES')]}
 assert native['local_bytes']==0 and owner.threads_per_cta==640 and native['max_threads']>=640,native
 ptx,cubin=compiled.__ptx__,compiled.__cubin__
 if isinstance(cubin,str):cubin=Path(cubin).read_bytes()
 assert isinstance(ptx,str) and isinstance(cubin,bytes) and cubin.startswith(b'\x7fELF')
 stem=a.output/f'{len(receipt["kernels"]):02d}-megamoe';stem.with_suffix('.ptx').write_text(ptx);stem.with_suffix('.cubin').write_bytes(cubin)
 sass=subprocess.check_output(['/usr/local/cuda/bin/cuobjdump','--dump-sass',str(stem.with_suffix('.cubin'))],text=True);stem.with_suffix('.sass').write_text(sass)
 resources=subprocess.check_output(['/usr/local/cuda/bin/cuobjdump','--dump-resource-usage',str(stem.with_suffix('.cubin'))],text=True);stem.with_suffix('.resources.txt').write_text(resources)
 cfg={key:getattr(owner,key) for key in ['mma_tiler','cluster_shape_mn','hidden','intermediate_downproj','world_size','num_transform_warpgroups','_fc1_k_tiles','_fc2_k_tiles']}
 cfg['mixed_stage_depths']={role:{key:getattr(getattr(owner,'mixed_'+role),key)for key in ['num_load2trans_stage','num_trans2mma_stage']}for role in ['fc1','fc2']}
 receipt['kernels'].append(dict(stem=stem.name,configuration=cfg,native_resources=native,compile_options=kwargs.get('options',''),ptx_sha256=hashlib.sha256(ptx.encode()).hexdigest(),cubin_sha256=hashlib.sha256(cubin).hexdigest(),sass_sha256=hashlib.sha256(sass.encode()).hexdigest()));save();return compiled
cute.compile=compile;mp=pytest.MonkeyPatch();save()
try:
 _check_nvfp4_kernel_matches_torch_reference(mp,mode='w4a16',tile_n=32,in_kernel_fc2_reduce=False,token_back_mode='epi_warps',apply_routing_weights_before_fc2=False,hidden=a.hidden,intermediate=a.intermediate,num_experts=4,topk=2)
 torch.cuda.synchronize();assert receipt['kernels'];verify();receipt.update(passed=True,finished=time.time());save();print(json.dumps(receipt))
except BaseException as e:
 receipt.update(error=repr(e),finished=time.time());save();raise
finally:cute.compile=original;mp.undo()
