"""Keep the two-cell ACCA diagnostic separate from its primary CAAC evidence."""
from pathlib import Path
import csv
import hashlib
import json

O = Path(__file__).resolve().parent
R = O.parents[1]
D = O / "reverse-prefill"
E = R / "evidence/w4-tail-cutoff-acca/1793394140932104000"
P = R / "evidence/w4-tail-cutoff-screen/1793393742504067000"
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
csvrows = lambda p: list(csv.DictReader(Path(p).open()))
c = read(E / "data/perf-config.json")
old = read(P / "data/perf-config.json")
assert c["sources"] == old["sources"] and c["observer_hashes"] == old["observer_hashes"]
assert c["phases"] == ["candidate", "control", "control", "candidate"]
rows = csvrows(E / "report/cells.csv")
prior = {(r["job"], r["tokens"]): r for r in csvrows(P / "report/cells.csv")}
phases = csvrows(E / "report/phase-components.csv")
clocks = read(E / "report/clock-quartiles.json")
resources = read(E / "report/resource-deltas.json")
summary = read(E / "report/summary.json")
assert summary["passed"] and summary["raw_samples"] == 800 and resources["all_resources_equal"]
bindings = {}
for row in rows:
    name = row["job"]
    fresh = read(E / "data/results" / name / "receipt.json")
    original = read(P / "data/results" / name / "receipt.json")
    assert fresh["gpu"] == original["gpu"]
    assert fresh["gpu_initial"].split(",")[0] == original["gpu_initial"].split(",")[0]
    assert fresh["winner_cache_manifest"] == original["winner_cache_manifest"]
    bindings[name] = dict(gpu=fresh["gpu"], uuid=fresh["gpu_initial"].split(",")[0],
                          original_receipt_sha256=sha(P / "data/results" / name / "receipt.json"),
                          repeat_receipt_sha256=sha(E / "data/results" / name / "receipt.json"))
pre = read(P / "data/release-postflight.json")
post = read(E / "data/release-postflight.json")
assert pre["native_modules"] == post["native_modules"]
lines = [
    "# Separate two-cell ACCA diagnostic",
    "",
    "Both jobs passed all four phases, source/cache postflight and raw CUPTI replay. These 800 samples stay separate from the original 39-cell CAAC screen. Same physical GPU per cell, immutable2b8/cbef sources, recorded choices/routes, release C++ libraries/Ninja descriptions, compiler flags and timing contract. No retuning, clock change, pooling, replacement or further repeats.",
    "",
    "| Cell | Primary CAAC | Separate ACCA | C repeat spread | A repeat spread | ACCA clock exceptions |",
    "|---|---:|---:|---:|---:|---:|",
]
for r in rows:
    qs = [q for q in clocks if q["job"] == r["job"]]
    count = sum(q["clock"]["sm_mhz"]["median"] != 2032 or set(q["clock"]["reasons"]) != {"0"} for q in qs)
    lines.append(f"| {r['model']} TP{r['tp']} T{r['tokens']} | {float(prior[(r['job'], r['tokens'])]['speedup_percent']):+.3f}% | {float(r['speedup_percent']):+.3f}% | {float(r['control_spread_percent']):.3f}% | {float(r['candidate_spread_percent']):.3f}% | {count}/16 |")
lines += [
    "",
    "V41F reverses sign because its second control is slower, with a lower-clock later trajectory. The original adverse observation remains preserved; this repeat does not establish a stable gain. N3U is nominally negative in both orders. Its two candidate medians lie between the controls in this repeat, whose clock trajectories vary; the repeated adverse sign still matters and is not erased by that variability. Both FC1 and FC2 durations/extensions rise for N3U in each block. The complete results do not isolate a clock-independent native-instruction cause.",
    "",
    "All phase component medians are shown in execution order. Durations overlap under PDL; do not sum them. Separate component medians/extensions need not sum exactly to the E2E median.",
    "",
    "| Cell | Phase | E2E µs | FC1 duration / extension µs | FC2 duration / extension µs | Combine duration / extension µs | Route-sort µs |",
    "|---|---|---:|---:|---:|---:|---:|",
]
for r in phases:
    def pair(n):
        return f"{float(r[n + '_us']):.3f} / {float(r[n + '_extension_us']):.3f}"
    lines.append(f"| {r['job']} T{r['tokens']} | {r['phase']} | {float(r['e2e_us']):.3f} | {pair('fc1')} | {pair('fc2')} | {pair('combine')} | {float(r['route_sort_us']):.3f} |")
lines += ["", "Every quartile is preserved below; SM values are min/median MHz, reasons are the complete observed reason-key set. There are 14/32 exception windows and no missing NVML windows.", "", "| Cell | Phase / quartile | E2E µs | SM min / median MHz | Reason keys |", "|---|---|---:|---:|---|"]
for q in clocks:
    k = q["clock"]
    lines.append(f"| {q['job']} T{q['tokens']} | {q['phase']} / {q['quartile']} | {q['medians']['e2e_us']:.3f} | {k['sm_mhz']['min']} / {k['sm_mhz']['median']} | {','.join(k['reasons'])} |")
lines += ["", "[Full raw evidence](../../../evidence/w4-tail-cutoff-acca/1793394140932104000/data) · [replayed table](../../../evidence/w4-tail-cutoff-acca/1793394140932104000/report/table.md) · [resource joins](../../../evidence/w4-tail-cutoff-acca/1793394140932104000/report/resource-deltas.json) · [original primary results](../RESULTS.md).", "", "Native driver resources remain unchanged for all four measured FC-stage configurations; 16 loaded function records have LOCAL0. This is not a timed-cubin identity claim. The initial launch-receipt formatting mismatch failed before GPU work and remains preserved in preflight-format-failure/."]
(D / "RESULTS.md").write_text("\n".join(lines) + "\n")
receipt = dict(passed=True, cells=2, samples=800, pooling_or_replacement=False, further_repeats=False,
               source_and_native_cohort_equal=True, same_gpu=bindings,
               primary_evidence=str((P / "data").relative_to(R)), repeat_evidence=str((E / "data").relative_to(R)),
               bindings={str(p.relative_to(R)): sha(p) for p in [E / "fetch-receipt.json", E / "data/campaign.json", E / "report/summary.json", E / "report/cells.csv", E / "report/phase-components.csv", E / "report/clock-quartiles.json", E / "report/resource-deltas.json", E / "data/release-postflight.json", D / "RESULTS.md"]})
(D / "result-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(dict(passed=True, cells=2, samples=800, receipt_sha256=sha(D / "result-receipt.json"))))
