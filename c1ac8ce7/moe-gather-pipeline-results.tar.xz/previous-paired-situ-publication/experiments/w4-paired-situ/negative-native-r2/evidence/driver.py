"""Four native captures of EP16/32 frozen winners; no latency measurements."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,os,shutil,signal,subprocess,time
R=Path('/data/ziangli/flashinfer-moe-gather-pipeline'); O=R/'experiments/w4-paired-situ/negative-native-r2'
C=json.loads((R/'runs/w4-paired-situ-screen/perf-config.json').read_text()); sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest=lambda p:{str(x.relative_to(p)):sha(x)for x in sorted(p.rglob('*'))if x.is_file()}
record=dict(passed=False,complete=False,started=time.time(),config_sha256=sha(R/'runs/w4-paired-situ-screen/perf-config.json'),helpers={p.name:sha(p)for p in O.glob('*.py')},runs=[],boundary='Existing public profile-cuda replay, one cold-L2 graph replay after normal prewarm. No NCU, timing samples, numerical oracle, tuning, compiler-option or production source changes.')
def save():(O/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
def verify(full=False):
 for role,s in C['sources'].items():
  files=json.loads(Path(s['tracked_manifest']).read_text())if full else s['source_sha256']
  for name,d in files.items():assert sha(Path(s['repo'])/name)==d,(role,name)
def idle(gpu):
 apps=subprocess.check_output(['nvidia-smi','-i',str(gpu),'--query-compute-apps=pid','--format=csv,noheader'],text=True).strip();assert not apps,(gpu,apps)
 return subprocess.check_output(['nvidia-smi','-i',str(gpu),'--query-gpu=uuid,memory.used,utilization.gpu','--format=csv,noheader,nounits'],text=True).strip()
def lane(pair):
 token,gpu=pair; rows=[]
 for role,s in C['sources'].items():
  verify();out=O/f'{role}-{token}';out.mkdir();cache=out/'cache';original=Path(C['jobs']['ep-kimi-k3-w4a16']['winner_cache']);before=manifest(original);shutil.copytree(original,cache)
  env={k:v for k,v in os.environ.items()if not k.startswith(('FLASHINFER_','TRTLLM_','CUTE_DSL_','FI_','REG_GUARD_'))and k not in ('CUDA_VISIBLE_DEVICES','PYTHONOPTIMIZE')}
  env.update(CUDA_VISIBLE_DEVICES=str(gpu),PYTHONPATH=os.pathsep.join(x for x in [s['repo'],C['python_deps']]if x),FLASHINFER_WORKSPACE_BASE=s['workspace_base'],CUTE_DSL_CACHE_DIR=s['cute_cache'],CUTE_DSL_KEEP='ptx,cubin',CUTE_DSL_DUMP_DIR=str(out/'compiler-artifacts'),CUDA_CACHE_PATH=C['driver_cache'],FLASHINFER_CUTE_DSL_STRICT_CACHE_KEY='1',FLASHINFER_CUDA_ARCH_LIST='10.3a',FLASHINFER_DIST_AWARE_AUTOTUNE='0',FLASHINFER_JIT_VERBOSE='0',FLASHINFER_JIT_DEBUG='0',TRTLLM_ENABLE_PDL='1',FLASHINFER_DISABLE_FP4_QUANT_FAST_MATH='0',TRTLLM_DISABLE_FP4_QUANT_FAST_MATH='0',OMP_NUM_THREADS='1',MAX_JOBS='4',PYTHONUNBUFFERED='1',FI_FROZEN_HEAD=s['head'],REG_GUARD_REPO=s['repo'],REG_GUARD_SOURCE=s['source_file'],REG_GUARD_KERNEL_SHA=s['source_sha256']['flashinfer/fused_moe/cute_dsl/blackwell/moe_w4a16_kernel.py'],REG_GUARD_OUTPUT=str(out/'register-guard'),REG_GUARD_CONTROL='80',REG_GUARD_GATHER='64',REG_GUARD_EPILOGUE='144')
  (out/'compiler-artifacts').mkdir()
  cmd=[C['python'],'-u',str(O/'capture.py'),'--repo',s['repo'],'--expected',str(O/f'expected-{token}.json'),'--output',str(out/'selection.json'),'--','--functional-api','--model','kimi-k3','--ep','8','--tp','1','--quant-family','nvfp4','--backends','cutedsl','--num-tokens',str(token),'--cache',str(cache),'--no-autotune','--profile-cuda','--profile-backend','cute-dsl-w4a16','--profile-iters','1','--swap-ab','--no-fused-finalize','--include-activation-quant','--warmup','10','--iters','100']
  row=dict(role=role,tokens=token,gpu=gpu,command=cmd,environment={k:v for k,v in env.items()if k.startswith(('CUTE_','REG_','FLASHINFER_','CUDA_','FI_'))},initial_idle=idle(gpu),started=time.time(),source=s,cache_manifest=before)
  print('START',role,token,flush=True)
  with(out/'run.log').open('w')as f:
   p=subprocess.Popen(cmd,cwd=s['repo'],env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
   try:code=p.wait(timeout=600)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait();raise
  row.update(returncode=code,finished=time.time());(out/'receipt.json').write_text(json.dumps(row,indent=2)+'\n');assert code==0,row
  assert manifest(cache)==manifest(original)==before
  assert json.loads((out/'selection.json').read_text())['complete']
  cap=json.loads(next((out/'loaded-codegen').glob('*/receipt.json')).read_text());assert [x['stage']for x in cap]==['fc1','fc2','combine']
  assert all(x['loaded_resources']['local_bytes']==0 for x in cap)
  row['final_idle']=idle(gpu);rows.append(row);print('PASS',role,token,flush=True)
 return rows
assert not(O/'receipt.json').exists();save()
try:
 readiness=json.loads((R/'experiments/w4-paired-situ/qualification/recovery-readiness.json').read_text());assert readiness['passed'] and readiness['native_all_noop'];assert sha(R/'runtime/recovery-1030/cache-ready.json')==readiness['records']['cache-ready.json']
 ready=json.loads((R/'runtime/recovery-1030/cache-ready.json').read_text()); record['release_modules']=ready['modules'];record['recovery_readiness_sha256']=sha(R/'experiments/w4-paired-situ/qualification/recovery-readiness.json')
 for m in ready['modules']:
  library=Path(m['library']);assert sha(library)==m['after']['library_sha256'] and sha(library.parent/'build.ninja')==m['after']['ninja_sha256'];assert 'no work to do'in subprocess.check_output(['ninja','-n','-C',str(library.parent)],text=True)
 verify(True);record['full_source_preflight']=True;save()
 with ThreadPoolExecutor(max_workers=2)as ex:rows=list(ex.map(lane,[(16,1),(32,3)]))
 record['runs']=[x for group in rows for x in group];verify(True);record.update(passed=True,complete=True,full_source_postflight=True,finished=time.time());save()
except BaseException as exc:record.update(complete=True,error=repr(exc),finished=time.time());save();raise
