"""Observe frozen native profiler choices/routes; no kernel or timing changes."""
import argparse
import contextlib
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time
import os
import subprocess

p = argparse.ArgumentParser()
p.add_argument('--repo', type=Path, required=True)
p.add_argument('--expected', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
p.add_argument('cli', nargs=argparse.REMAINDER)
a = p.parse_args()
cli = a.cli[1:] if a.cli and a.cli[0] == '--' else a.cli
assert '--no-autotune' in cli and '--profile-cuda' in cli
cache = Path(cli[cli.index('--cache') + 1])
def manifest():
    return {str(p.relative_to(cache)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(cache.rglob('*')) if p.is_file()}
before = manifest()
assert before
expected = json.loads(a.expected.read_text())
source = a.repo / 'benchmarks/bench_moe_deepseek.py'
sys.path[:0] = [str(a.repo), str(source.parent)]
spec = importlib.util.spec_from_file_location('profile_native_benchmark', source)
b = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = b
spec.loader.exec_module(b)
from flashinfer.autotuner import AutoTuner
from flashinfer.autotuner.autotuner import _tactic_to_json
import flashinfer
assert Path(flashinfer.__file__).resolve().parent == a.repo / 'flashinfer'
records, contexts, routes = [], [], []
original = AutoTuner.search_cache

def search(self, custom_op, runners, input_shapes, tuning_config, inputs=None, **kw):
    result = original(self, custom_op, runners, input_shapes, tuning_config, inputs, **kw)
    if custom_op.startswith(('CuteDslFusedMoE::', 'CuteDslMoEWrapper::')):
        hit, rid, tactic, _ = result
        assert hit and not self.is_tuning_mode, custom_op
        runner = runners[rid]
        key = self._get_cache_key(custom_op, runner, input_shapes, tuning_config,
                                 runner.get_cache_key_extras(inputs) if inputs is not None else ()).file_key
        row = dict(operation=custom_op, runner=type(runner).__name__, key=key,
                   tactic=_tactic_to_json(tactic))
        assert row in expected['selections'], row
        if row not in records:
            records.append(row)
    return result

def forbidden_profile(*args, **kwargs):
    raise AssertionError('Frozen profiler replay attempted tactic search')

original_context = b._autotune_context
@contextlib.contextmanager
def observed_context(do_autotune, cache, measurement_policy=None):
    assert not do_autotune
    policy = measurement_policy.manifest_fields() if measurement_policy is not None else None
    if policy is not None:
        assert policy['measure_execution_mode'] == 'cuda_graph', policy
    with original_context(do_autotune, cache, measurement_policy):
        yield
    contexts.append(dict(enabled=bool(do_autotune), measurement_policy=policy))

original_histogram = b._collect_expert_histogram
def observed_histogram(inputs, num_local, local_offset):
    allocator = b._routing_tensors
    captured = []
    def capture(*args, **kwargs):
        result = allocator(*args, **kwargs)
        captured.append(result)
        return result
    b._routing_tensors = capture
    try:
        result = original_histogram(inputs, num_local, local_offset)
    finally:
        b._routing_tensors = allocator
    assert len(captured) == 1
    weights, ids = (tensor.detach().cpu().contiguous() for tensor in captured[0])
    route = dict(ids_sha256=hashlib.sha256(ids.numpy().tobytes()).hexdigest(),
                 weights_sha256=hashlib.sha256(weights.numpy().tobytes()).hexdigest(),
                 ids_dtype=str(ids.dtype), weights_dtype=str(weights.dtype),
                 shape=list(ids.shape),
                 full_expert_histogram=ids.reshape(-1).bincount(minlength=b.CFG.num_experts).tolist(),
                 local_expert_offset=local_offset, num_local_experts=num_local,
                 capture='Existing untimed histogram routing outputs; no extra routing invocation')
    assert route == expected['routing_identity'], route
    routes.append(route)
    return result

AutoTuner.search_cache = search
AutoTuner._profile_single_kernel = forbidden_profile
b._autotune_context = observed_context
b._collect_expert_histogram = observed_histogram
receipt = dict(complete=False, started=time.time(),
               benchmark_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
               cache_manifest=before, expected_sha256=hashlib.sha256(a.expected.read_bytes()).hexdigest(),
               cli=cli, selections=records, contexts=contexts, routes=routes)
a.output.parent.mkdir(parents=True, exist_ok=True)
from register_guard import install
finish_guard = install()
from flashinfer.fused_moe.cute_dsl import tuner as moe_tuner
from w4_resolution_observer import install as install_w4_resolution
resolved = {}
install_w4_resolution(moe_tuner, lambda: resolved, _tactic_to_json)
receipt['w4_resolution'] = resolved

import cutlass.cute as cute
import cuda.bindings.driver as cuda
def checked(v):
    assert v[0] == cuda.CUresult.CUDA_SUCCESS, v
    return v[1] if len(v) == 2 else v[1:]
original_compile = cute.compile
artifacts = a.output.parent / 'loaded-codegen' / str(os.getpid())
artifacts.mkdir(parents=True, exist_ok=False)
compiled_records = []
def capture_compile(*args, **kwargs):
    kernel = getattr(args[0], '__self__', args[0])
    compiled = original_compile(*args, **kwargs)
    if type(kernel).__name__ not in ('Sm100W4A16GroupedGemmKernel', '_MoeFinalizeKernel'):
        return compiled
    stem = ('fc1' if kernel.gather_input else 'fc2') if type(kernel).__name__ == 'Sm100W4A16GroupedGemmKernel' else 'combine'
    cubin = compiled.__cubin__
    cubin_path = cubin if isinstance(cubin, str) else None
    if cubin_path is not None:
        cubin = Path(cubin_path).read_bytes()
    assert isinstance(cubin, bytes) and cubin.startswith(b'\x7fELF')
    ptx = compiled.__ptx__
    assert isinstance(ptx, str) and '.version ' in ptx
    (artifacts / (stem + '.cubin')).write_bytes(cubin)
    (artifacts / (stem + '.ptx')).write_text(ptx)
    sass = subprocess.check_output(['/usr/local/cuda/bin/cuobjdump', '--dump-sass', str(artifacts / (stem + '.cubin'))], text=True)
    (artifacts / (stem + '.sass')).write_text(sass)
    library = cuda.CUlibrary(int(compiled.library))
    device = checked(cuda.cuCtxGetDevice())
    assert int(checked(cuda.cuLibraryGetKernelCount(library))) == 1
    native_kernel = checked(cuda.cuLibraryEnumerateKernels(1, library))[0]
    resources = {key:int(checked(cuda.cuKernelGetAttribute(getattr(cuda.CUfunction_attribute, 'CU_FUNC_ATTRIBUTE_'+attr), native_kernel, device))) for key,attr in [('initial_regs','NUM_REGS'),('max_threads','MAX_THREADS_PER_BLOCK'),('local_bytes','LOCAL_SIZE_BYTES'),('static_shared_bytes','SHARED_SIZE_BYTES'),('binary_version','BINARY_VERSION')]}
    assert resources['local_bytes'] == 0
    configuration = None
    if stem != 'combine':
        guard = json.loads((Path(os.environ['REG_GUARD_OUTPUT']) / str(os.getpid()) / 'receipt.json').read_text())['compilations'][-1]
        assert guard['gather_input'] == bool(kernel.gather_input)
        assert resources == guard['analysis']
        configuration = {k:guard[k] for k in ('route_tile','cta_group_size','tile_k','mma_tiler_mnk','cluster_shape_mn','raster_along_m','use_clc_scheduler','enable_pdl')}
    compiled_records.append(dict(stage=stem, loaded_resources=resources, compile_options=kwargs.get('options', ''), configuration=configuration, native_cubin_path=cubin_path, cubin_sha256=hashlib.sha256(cubin).hexdigest(), ptx_sha256=hashlib.sha256(ptx.encode()).hexdigest(), sass_sha256=hashlib.sha256(sass.encode()).hexdigest()))
    (artifacts / 'receipt.json').write_text(json.dumps(compiled_records, indent=2) + '\n')
    return compiled
cute.compile = capture_compile
exitstatus = 1
try:
    sys.argv = [str(source), *cli]
    rc = b.main()
    assert rc in (None, 0) and records == expected['selections']
    assert len(routes) == 1 and len(contexts) == 2
    assert contexts[0] == contexts[1]
    assert manifest() == before
    configs = resolved['w4_resolved_configs']
    assert len(configs) == 2
    normalize = lambda row: {k:v for k,v in row.items() if k != 'compiled_library'}
    assert [normalize(row) for row in configs] == expected['resolved_configs']
    guard_rows = json.loads((Path(os.environ['REG_GUARD_OUTPUT']) / str(os.getpid()) / 'receipt.json').read_text())['compilations']
    for row in configs:
        matched = [g for g in guard_rows if g['library_handle'] == row['compiled_library']]
        assert len(matched) == 1
        g = matched[0]
        assert g['gather_input'] == (row['stage'] == 'fc1')
        for key in ('mma_tiler_mnk','cluster_shape_mn','raster_along_m','use_clc_scheduler','enable_pdl'):
            assert g[key] == row[key], key
    receipt.update(complete=True, finished=time.time())
    exitstatus = 0
finally:
    finish_guard(exitstatus)
    a.output.write_text(json.dumps(receipt, indent=2) + '\n')
