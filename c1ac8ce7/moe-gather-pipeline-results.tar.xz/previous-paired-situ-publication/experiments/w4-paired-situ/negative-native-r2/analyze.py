"""Source-bound native comparison for the two original tight-negative tactics."""
from pathlib import Path
from collections import Counter
import hashlib,json,re,difflib
O=Path(__file__).resolve().parent;E=O/'evidence';R=O.parents[2]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=json.loads((E/'receipt.json').read_text());assert r['complete']and r['passed']and r['full_source_preflight']and r['full_source_postflight']and len(r['runs'])==4
for name,d in r['helpers'].items():assert sha(E/name)==d
main=R/'evidence/w4-paired-situ-screen/1793379864881706000/data';config=json.loads((main/'perf-config.json').read_text());assert sha(main/'perf-config.json')==r['config_sha256']
rx=re.compile(r'/\*([0-9a-fA-F]+)\*/\s+((?:@!?P\w+\s+)?([A-Za-z][A-Za-z0-9_.]*)(?=[\s;]).*?;)')
def decode(s):return[(int(m[1],16),m[2],m[3])for m in rx.finditer(s)]
rows=[]
for token in (16,32):
 caps={};paths={};expected=json.loads((E/f'expected-{token}.json').read_text());joined={}
 for role in ('control','candidate'):
  p=E/f'{role}-{token}';rec=json.loads((p/'receipt.json').read_text());assert rec['returncode']==0 and rec['source']==config['sources'][role]
  s=json.loads((p/'selection.json').read_text());assert s['complete']and s['selections']==expected['selections']and s['routes']==[expected['routing_identity']]
  assert [{k:v for k,v in q.items()if k!='compiled_library'}for q in s['w4_resolution']['w4_resolved_configs']]==expected['resolved_configs']
  capfile=next((p/'loaded-codegen').glob('*/receipt.json'));paths[role]=capfile.parent;cap=json.loads(capfile.read_text());assert[x['stage']for x in cap]==['fc1','fc2','combine'];caps[role]={x['stage']:x for x in cap}
  guard=json.loads(next((p/'register-guard').glob('*/receipt.json')).read_text());assert guard['exitstatus']==0 and guard['all_guarded']and not guard['compiler_options_changed']
  for k in cap:
   assert k['loaded_resources']['local_bytes']==0
   for ext in ('ptx','cubin','sass'):assert sha(capfile.parent/(k['stage']+'.'+ext))==k[ext+'_sha256']
 for stage in ('fc1','fc2','combine'):
  c,a=caps['control'][stage],caps['candidate'][stage];assert c['configuration']==a['configuration']and c['compile_options']==a['compile_options']and c['loaded_resources']==a['loaded_resources']
  files={role:paths[role]/stage for role in paths};sass={role:decode(p.with_suffix('.sass').read_text())for role,p in files.items()};counts={role:Counter(x[2]for x in v)for role,v in sass.items()};delta={op:counts['candidate'][op]-counts['control'][op]for op in sorted(counts['candidate']|counts['control'])if counts['candidate'][op]!=counts['control'][op]};equal={ext:c[ext+'_sha256']==a[ext+'_sha256']for ext in ('ptx','cubin','sass')}
  if stage!='fc1':assert all(equal.values())
  else:
   assert not counts['candidate']['FFMA']and not counts['candidate']['FFMA2']
   ptx={role:p.with_suffix('.ptx').read_text()for role,p in files.items()}
   sfus={role:Counter(re.findall(r'\b((?:ex2|rcp)\.[A-Za-z0-9_.]+)\s',text))for role,text in ptx.items()};assert sfus['control']==sfus['candidate'];assert'mul.rn.f32x2'in ptx['candidate']and'sub.rn.f32x2'in ptx['candidate']
  arith={'FADD','FADD2','FMUL','FMUL2','NOP'}
  nonarith={role:[x[2]for x in v if x[2]not in arith]for role,v in sass.items()}
  opcodes_equal_without_math=nonarith['control']==nonarith['candidate']
  prefix=0
  for u,v in zip(sass['control'],sass['candidate']):
   if u[1]!=v[1]:break
   prefix+=1
  row=dict(tokens=token,stage=stage,raw_equal=equal,configuration=c['configuration'],resources=c['loaded_resources'],same_options=True,same_resources=True,non_nop={role:sum(v.values())-v['NOP']for role,v in counts.items()},opcode_delta=delta,nonarith_opcode_sequence_equal=opcodes_equal_without_math,exact_instruction_prefix=prefix,opcode_counts={role:dict(v)for role,v in counts.items()},hashes={role:{ext:caps[role][stage][ext+'_sha256']for ext in ('ptx','cubin','sass')}for role in caps});rows.append(row)
  if stage=='fc1':
   diff='\n'.join(difflib.unified_diff([x[1]for x in sass['control']],[x[1]for x in sass['candidate']],fromfile='control',tofile='candidate',n=3))+'\n';(O/f'token-{token}-fc1-instructions.diff').write_text(diff)
summary=dict(passed=True,native_pairs=6,resource_changes=0,zero_local=True,unaffected_pairs_raw_identical=4,source_config_sha256=r['config_sha256'],capture_receipt_sha256=sha(E/'receipt.json'),archive_sha256=sha(O/'evidence.tar.gz'),native_release_modules=r['release_modules'],rows=rows,boundary='Exact frozen EP16/32 benchmark winner capture, no new latency or numerical-oracle results. Same compile options; artifact retention only. Routing ELF and source are unchanged; FC2/finalizer native images compared explicitly. Instruction-count equality does not prove equivalent runtime instruction scheduling or allocation-address effects.')
(O/'native-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items()if k not in ('rows','native_release_modules')}))
for row in rows:print(json.dumps({k:row[k]for k in ('tokens','stage','raw_equal','non_nop','opcode_delta','nonarith_opcode_sequence_equal','exact_instruction_prefix')}))
