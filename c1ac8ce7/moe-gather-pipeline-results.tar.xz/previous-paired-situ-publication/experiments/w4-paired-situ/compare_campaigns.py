"""Compare primary full26 CAAC with separate six-cell ACCA; never replace rows."""
from pathlib import Path
import json,csv,hashlib,math
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
P=R/'evidence/w4-paired-situ-screen/1793379864881706000';Q=R/'evidence/w4-paired-situ-acca/1793380968593160000'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
configs=[read(x/'data/perf-config.json')for x in (P,Q)]
assert configs[0]['phases']==['control','candidate','candidate','control']and configs[1]['phases']==['candidate','control','control','candidate']
for role in ('control','candidate'):
 a,b=[dict(x['sources'][role])for x in configs]
 for key in ('source_file','tracked_manifest'):a.pop(key);b.pop(key)
 assert a==b
for key in ('control_head','observer','observer_hashes','python','python_deps','driver_cache','estimator','register_policies','default_w4a16_moe_tactic','recovery_readiness_sha256'):assert configs[0][key]==configs[1][key]
primary={(x['job'],int(x['tokens'])):x for x in csv.DictReader((P/'report/cells.csv').open())};repeat={(x['job'],int(x['tokens'])):x for x in csv.DictReader((Q/'report/cells.csv').open())};assert len(primary)==26 and len(repeat)==6 and set(repeat)<=set(primary)
components=[{(x['job'],int(x['tokens'])):x for x in csv.DictReader((f/'report/component-deltas.csv').open())}for f in (P,Q)]
rows=[]
for key, b in repeat.items():
 a=primary[key];cs=[d[key]for d in components];job,token=key
 route_proofs=[]
 for root in (P,Q):
  phases=read(root/'data/results'/job/'receipt.json')['phases'];proof=[]
  for phase in phases:
   data=read(root/'data/results'/job/f"{phase['index']}-{phase['role']}"/'results.json');i=[r['tokens']for r in data['rows']].index(token)
   m=data['native_diagnostic']['measurements'][i];route=data['rows'][i]['routing_identity'];choices={json.dumps({k:h[k]for k in ('key','tactic','runner')},sort_keys=True)for h in m['cache_hits']}
   assert len(choices)==1;configs=[{k:v for k,v in row.items()if k!='compiled_library'}for row in m['w4_resolved_configs']]
   proof.append(dict(route=route,choice=next(iter(choices)),resolved=configs))
  assert all(x==proof[0]for x in proof);route_proofs.append(proof[0])
 assert route_proofs[0]==route_proofs[1]
 row=dict(job=job,tokens=token,primary_speedup_percent=float(a['speedup_percent']),repeat_speedup_percent=float(b['speedup_percent']),primary_components={k:float(cs[0][k])for k in ('delta_e2e_us','delta_route_sort_us','delta_fc1_us','delta_fc2_extension_us')},repeat_components={k:float(cs[1][k])for k in ('delta_e2e_us','delta_route_sort_us','delta_fc1_us','delta_fc2_extension_us')},primary_spreads={x:float(a[x+'_spread_percent'])for x in ('control','candidate')},repeat_spreads={x:float(b[x+'_spread_percent'])for x in ('control','candidate')},same_route_choice_and_native_configuration=True);rows.append(row)
summary=dict(passed=True,primary_cells=26,repeat_cells=6,primary_source_sha256=sha(P/'data/perf-config.json'),repeat_source_sha256=sha(Q/'data/perf-config.json'),primary_summary_sha256=sha(P/'report/summary.json'),repeat_summary_sha256=sha(Q/'report/summary.json'),rows=rows,boundary='The primary26 CAAC remains unchanged. The six-cell ACCA diagnostic has a smaller token set and reversed phase order; it tests repeatability, not a unique causal explanation for order or allocation changes. All samples/negatives retained. No pooled/replacement aggregate.')
(O/'campaign-comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
lines=['# Separate six-cell opposite-order check','','This diagnostic follows A–C–C–A on the same original GPUs and uses the same source, frozen choices/routes, native configuration, CUDA Graph/CUPTI100 samples,10 warmups, and cold-L2 contract. It is **additional evidence**, not a replacement for the original26 C–A–A–C observations. The selected token set differs, so a changed result cannot be attributed uniquely to phase ordering.','','| Shape | Tokens | Original CAAC | Repeat ACCA | Repeat C spread | Repeat A spread |','|---|---:|---:|---:|---:|---:|']
for row in rows:lines.append(f"| K3 {'EP8'if row['job'].startswith('ep-')else'TP8'} | {row['tokens']} | {row['primary_speedup_percent']:+.3f}% | {row['repeat_speedup_percent']:+.3f}% | {row['repeat_spreads']['control']:.3f}% | {row['repeat_spreads']['candidate']:.3f}% |")
lines+=['','The tight original EP16/32 losses do not persist. In the repeat, FC1 spans are0.048/0.104us shorter and routing is0.016/0.096us shorter. EP128 remains−0.101%, but its FC1 span improves0.015us while routing increases0.352us. This supports treating the original losses as an uncertain end-to-end execution effect rather than an established arithmetic regression.','','All three repeated prefill points are positive, but repeat spread reaches3.07% and four clock-exception quartiles remain. Neither the primary+1.10% nor diagnostic+1.03% prefill aggregate establishes a dependable speedup.','','Actual execution order and raw phase medians:','','| Shape | Tokens | A1 | C1 | C2 | A2 |','|---|---:|---:|---:|---:|---:|']
for key,b in repeat.items():lines.append(f"| K3 {'EP8'if key[0].startswith('ep-')else'TP8'} | {key[1]} | {float(b['a1_us']):.4f} | {float(b['c1_us']):.4f} | {float(b['c2_us']):.4f} | {float(b['a2_us']):.4f} |")
lines+=['','2,400 raw samples,48 loaded functions,unchanged native resource policies and LOCAL0; all source/cache/route/native configuration/timing guards passed. No retuning, modified production options, dropped samples, or added policy. The original26 contain10,400 samples and remain primary. GPUs1/3 were checked idle and released after the campaign.','','Raw diagnostic: `evidence/w4-paired-situ-acca/1793380968593160000/data`; standard complete report in sibling `report/`. The standard report labels C/A columns by arm for comparison; its actual phase labels and the table above preserve A–C–C–A chronology.']
(O/'ACCA.md').write_text('\n'.join(lines)+'\n')
s=(O/'PERFORMANCE.md').read_text().replace('result pending.', 'complete; see `ACCA.md` and `campaign-comparison.json`.');(O/'PERFORMANCE.md').write_text(s)
print(json.dumps(dict(passed=True,primary=26,repeat=6,sha256=sha(O/'campaign-comparison.json'))))
