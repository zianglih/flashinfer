"""Replay recorded stage spans for tight negative EP cases; no new measurement."""
from pathlib import Path
from statistics import median
from collections import Counter
import csv,json,hashlib
R=Path(__file__).resolve().parents[3];O=Path(__file__).resolve().parent
E=R/'evidence/w4-paired-situ-screen/1793379864881706000/data/results/ep-kimi-k3-w4a16'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
samples=json.loads((E/'component-samples.json').read_text());rows=[];names={};resources=[]
for phase in ('0-control','1-candidate','2-candidate','3-control'):
 result=json.loads((E/phase/'results.json').read_text());guard=json.loads(next((E/'register-guard'/phase).glob('*/receipt.json')).read_text());bylib={x['library_handle']:x for x in guard['compilations']}
 for token in (16,32,64,128,256):
  selected=[x for x in samples if x['phase']==phase and x['tokens']==token];assert len(selected)==100
  measure=result['native_diagnostic']['measurements'][[x['tokens']for x in result['rows']].index(token)]
  route_names=Counter(x[0]for x in measure['activities']if 'routingIndicesClusterKernel'in x[0]);assert len(route_names)==1 and list(route_names.values())==[100]
  names.setdefault(str(token),[]).append(next(iter(route_names)))
  configs=measure['w4_resolved_configs'];assert len(configs)==2
  joined=[]
  for config in configs:
   native=bylib[config['compiled_library']];assert native['gather_input']==(config['stage']=='fc1')
   for k in ('mma_tiler_mnk','cluster_shape_mn','raster_along_m','use_clc_scheduler','enable_pdl'):assert config[k]==native[k]
   joined.append(dict(stage=config['stage'],configuration={k:v for k,v in config.items()if k!='compiled_library'},resources=native['analysis'],options=native['compile_options']))
  resources.append(dict(phase=phase,tokens=token,stages=joined))
  keys=['e2e_us','route_sort_us','fc1_start_us','fc1_us','fc1_extension_us','fc2_us','fc2_extension_us','combine_extension_us']
  row={k:median(x[k]for x in selected)for k in keys};row.update(phase=phase,tokens=token,fc1_route_overlap_us=median(max(0,min(x['route_sort_end_us'],x['fc1_end_us'])-max(x['route_sort_start_us'],x['fc1_start_us']))for x in selected),samples=len(selected));rows.append(row)
for names_for_token in names.values():assert len(set(names_for_token))==1
for token in (16,32,64,128,256):
 configs=[x['stages']for x in resources if x['tokens']==token];assert all(x==configs[0]for x in configs)
summary=dict(passed=True,source='49 control versus5e61 candidate',samples=2000,raw_component_sha256=sha(E/'component-samples.json'),native_results_sha256={x:sha(E/x/'results.json')for x in ('0-control','1-candidate','2-candidate','3-control')},phases=rows,route_names={k:v[0]for k,v in names.items()},resource_joins=resources,boundary='Stage medians replayed from all original samples; same native config/resources/route function per token. Medians of components need not add exactly to E2E median. Route delay begins before FC1 start; this localizes recorded time but does not identify a causal mechanism or excuse negative E2E results.')
(O/'component-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
with(O/'component-phases.csv').open('w')as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
lines=['# Tight-negative EP stage trace','','All100 samples per phase are retained. Values below are medians in microseconds; component medians do not necessarily add to E2E.','','| Tokens | Phase | E2E | Routing | FC1 start | Route/FC1 overlap | FC1 span | FC1 extension | FC2 extension | Combine extension |','|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|']
for x in rows:
 if x['tokens']in (16,32):lines.append('| '+str(x['tokens'])+' | '+x['phase']+' | '+' | '.join(f'{x[k]:.4f}'for k in ['e2e_us','route_sort_us','fc1_start_us','fc1_route_overlap_us','fc1_us','fc1_extension_us','fc2_extension_us','combine_extension_us'])+' |')
lines+=['','T16: candidate E2E +0.87175us; routing +0.86375us; FC1 span +0.11975us; FC2 extension -0.04825us. T32: E2E +0.83250us; routing +1.15975us; FC1 span +0.19175us; FC2 extension -0.43975us. All four phases report2032MHz and no throttle reason for these two points.','','The changed SiTU instructions execute in FC1 epilogue. Most extra latency is already present before FC1 starts. This does not establish that packing arithmetic caused slower routing or a compiler scheduling regression; native instruction comparison and one opposite-order check can distinguish codegen facts from process/order-dependent execution. The original negative E2E rows remain valid observations.']
(O/'COMPONENTS.md').write_text('\n'.join(lines)+'\n');print(json.dumps(dict(passed=True,rows=len(rows),sha256=sha(O/'component-summary.json'))))
