"""Run the seven existing candidate-only exact/native calls after owner preflight."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,os,signal,subprocess,sys,time,threading
H=Path(__file__).resolve().parent;P=H.parent;R=Path('/data/ziangli/flashinfer-moe-gather-pipeline');O=R/'runs/pr7290-retained-refresh'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
plan=json.loads((H/'plan.json').read_text());s=json.loads((P/'screen/source-candidate.json').read_text());pre=json.loads((O/'launch-preflight.json').read_text());assert pre['passed']
assert sha(P/'source-full.json')==plan['source_full_sha256']and sha(P/'screen/source-candidate.json')==plan['source_record_sha256']
proof=json.loads((H/'helper-proof.json').read_text())
receipt=dict(started=time.time(),complete=False,passed=False,head=s['head'],runs=[],plan_sha256=sha(H/'plan.json'),helper_proof_sha256=sha(H/'helper-proof.json'),source_sha256=sha(P/'screen/source-candidate.json'),preflight_sha256=sha(O/'launch-preflight.json'))
lock=threading.Lock()
def save():
 with lock:(H/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
def native():
 for row in pre['native_modules']:
  p=Path(row['library']);assert sha(p)==row['library_sha256']and sha(p.parent/'build.ninja')==row['ninja_sha256']
def idle(gpu):
 for _ in range(20):
  apps=subprocess.check_output(['nvidia-smi','-i',str(gpu),'--query-compute-apps=pid','--format=csv,noheader'],text=True).strip();line=subprocess.check_output(['nvidia-smi','-i',str(gpu),'--query-gpu=uuid,memory.used,utilization.gpu','--format=csv,noheader,nounits'],text=True).strip();u,m,v=[x.strip()for x in line.split(',')]
  if not apps and int(m)<=16 and int(v)==0:
   assert u==next(x['uuid']for x in pre['idle']if x['gpu']==gpu);return dict(gpu=gpu,uuid=u,memory_mib=int(m),utilization=int(v),pids=apps)
  time.sleep(1)
 raise AssertionError((gpu,line,apps))
base={k:v for k,v in os.environ.items()if not k.startswith(('FLASHINFER_','TRTLLM_','CUTE_DSL_','REG_GUARD_','CODEGEN_','SMOKE_','FI_'))and k not in('CUDA_VISIBLE_DEVICES','PYTHONOPTIMIZE')}
base.update(PYTHONPATH=s['repo'],FLASHINFER_WORKSPACE_BASE=s['workspace_base'],FLASHINFER_CUBIN_DIR=s['cubin_dir'],CUTE_DSL_CACHE_DIR=s['cute_cache'],FLASHINFER_CUDA_ARCH_LIST='10.3a',FLASHINFER_CUTE_DSL_STRICT_CACHE_KEY='1',FLASHINFER_DIST_AWARE_AUTOTUNE='0',TRTLLM_ENABLE_PDL='1',FLASHINFER_DISABLE_FP4_QUANT_FAST_MATH='0',TRTLLM_DISABLE_FP4_QUANT_FAST_MATH='0',OMP_NUM_THREADS='1',MAX_JOBS='4',FLASHINFER_JIT_VERBOSE='0',FLASHINFER_JIT_DEBUG='0',PYTHONUNBUFFERED='1')
def case(c):
 d=H/c['name'];d.mkdir();(d/'compiler-artifacts').mkdir();gpu=c['gpu'];idle_before=idle(gpu)
 env=dict(base,CUDA_VISIBLE_DEVICES=str(gpu),REG_GUARD_SOURCE=str(P/'screen/source-candidate.json'),REG_GUARD_REPO=s['repo'],REG_GUARD_KERNEL_SHA=s['source_sha256'][c['kernel_path']],REG_GUARD_OUTPUT=str(d/'register-guard'),CODEGEN_OUTPUT=str(d/'codegen'),CUTE_DSL_KEEP='ptx,cubin',CUTE_DSL_DUMP_DIR=str(d/'compiler-artifacts'),FLASHINFER_JIT_BUILD_LOG=str(d/'native-build.jsonl'),**c['environment'])
 env.update({'REG_GUARD_'+k.upper():str(v)for k,v in c['register_policy'].items()})
 command=[sys.executable,'-u',str(H/c['helper']),*[x.format(repo=s['repo'],output=d)for x in c['arguments']]]
 row=dict(name=c['name'],gpu=gpu,command=command,started=time.time(),idle_before=idle_before,environment={k:v for k,v in env.items()if k not in os.environ or os.environ[k]!=v})
 (d/'run.json').write_text(json.dumps(row,indent=2)+'\n');print('START',c['name'],gpu,flush=True)
 with(d/'stdout.log').open('w')as log:
  child=subprocess.Popen(command,cwd=s['repo'],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=child.wait(timeout=1800)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait();row['timeout']=True
 row.update(returncode=code,finished=time.time(),stdout_sha256=sha(d/'stdout.log'));(d/'run.json').write_text(json.dumps(row,indent=2)+'\n');receipt['runs'].append(row);save();assert code==0,row
 assert json.loads((d/'result.json').read_text())['passed'];capture=json.loads((d/'codegen/receipt.json').read_text());assert capture['exitstatus']==0 and len(capture['kernels'])==3
 assert all(k['native_resources']['local_bytes']==0 for k in capture['kernels'])
 if c['native_scheduler']:assert all(k['configuration']['use_clc_scheduler']for k in capture['kernels']if k['kind']=='Sm100BlockScaledGroupedGemmKernel')
 row.update(result_sha256=sha(d/'result.json'),capture_sha256=sha(d/'codegen/receipt.json'),native_resources=[k['native_resources']for k in capture['kernels']]);save();print('PASS',c['name'],flush=True)
save()
try:
 native()
 with ThreadPoolExecutor(max_workers=7)as pool:list(pool.map(case,plan['cases']))
 files=json.loads((P/'screen/candidate-tracked.json').read_text());assert len(files)==13245
 for n,h in files.items():assert sha(Path(s['repo'])/n)==h,n
 native();receipt.update(complete=True,passed=True,full_source_postflight=True,native_cache_unchanged=True,finished=time.time(),gpu_release=[idle(g)for g in plan['gpus']]);save()
except BaseException as e:receipt.update(complete=True,passed=False,error=repr(e),finished=time.time());save();raise
