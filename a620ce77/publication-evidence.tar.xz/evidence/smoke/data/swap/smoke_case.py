"""Bounded local smoke: reuse repository zero-tolerance oracle, no source edits."""
import argparse,inspect,json,os,pathlib,sys,time
p=argparse.ArgumentParser();p.add_argument('--repo',type=pathlib.Path,required=True);p.add_argument('--mode',choices=['w4a16','w4a4','per-token','w4a8','mxfp8'],required=True);p.add_argument('--case',type=int,required=True);p.add_argument('--activation',choices=['Swiglu','Relu2'],default='Swiglu');p.add_argument('--output',type=pathlib.Path,required=True);p.add_argument('--k-steps',type=int,choices=[4,8],default=4);a=p.parse_args()
sys.path.insert(0,str(a.repo))
import pytest,torch,flashinfer
from tests.moe import test_cute_dsl_fused_moe as existing
from flashinfer.tllm_enums import ActivationType
# k_tiles=1 is shorter than either load ring. Small-SM correctness-only cap
# forces multiple work tiles/CLC metadata wraps without a large tensor oracle.
cases=[
 dict(tokens=1,h=256,i=128,n=16,m=128,clc=False,pdl=False,swap=True),
 dict(tokens=129,h=256,i=128,n=16,m=128,clc=True,pdl=True,swap=True),
 dict(tokens=129,h=384,i=128,n=32,m=256,clc=False,pdl=True,swap=True),
 dict(tokens=129,h=384,i=128,n=32,m=256,clc=True,pdl=False,swap=True),
 dict(tokens=129,h=256,i=128,n=16,m=128,clc=False,pdl=True,swap=False),
 dict(tokens=129,h=256,i=128,n=32,m=256,clc=True,pdl=False,swap=False),
 dict(tokens=17,h=1024,i=4096,n=16,m=128,clc=True,pdl=True,swap=True),
 dict(tokens=17,h=4096,i=1024,n=32,m=256,clc=False,pdl=True,swap=True),
 dict(tokens=17,h=1024,i=512,n=128,m=512,clc=True,pdl=True,swap=True),
 dict(tokens=193,h=1024,i=512,n=128,m=128,clc=False,pdl=True,swap=True),
 dict(tokens=385,h=1024,i=512,n=256,m=128,clc=True,pdl=True,swap=True),
 dict(tokens=385,h=384,i=128,n=256,m=256,clc=False,pdl=False,swap=True),
 dict(tokens=193,h=1024,i=512,n=128,m=512,clc=True,pdl=True,swap=True),
 dict(tokens=4096,h=256,i=128,n=16,m=128,clc=True,pdl=True,swap=True),
 dict(tokens=193,h=1024,i=640,n=128,m=512,clc=True,pdl=True,swap=True),
]
cases.append(dict(tokens=4096,h=384,i=128,n=32,m=256,clc=True,pdl=True,swap=True))
cases.append(dict(tokens=17,h=1024,i=640,n=16,m=512,clc=True,pdl=True,swap=True))
c=cases[a.case];assert a.mode=='w4a16' or c['swap']
a.output.parent.mkdir(parents=True,exist_ok=True)
receipt=dict(mode=a.mode,activation=a.activation,case=c,started=time.time(),repo=str(a.repo),control_boundary='Correctness only: public API and existing bit-exact oracle, 2-active-cluster/SM cap, explicit CLC selector for W4; native performance launches do not apply these overrides.')
def save():a.output.write_text(json.dumps(receipt,indent=2)+'\n')
save()
mp=pytest.MonkeyPatch()
original=flashinfer.cute_dsl_fused_moe
mp.setattr(flashinfer,'cute_dsl_fused_moe',lambda *args,**kwargs:original(*args,**dict(kwargs,enable_pdl=c['pdl'])))
old_init=flashinfer.CuteDslMoEWrapper.__init__
def init(self,*args,**kwargs):return old_init(self,*args,**dict(kwargs,enable_pdl=c['pdl']))
mp.setattr(flashinfer.CuteDslMoEWrapper,'__init__',init)
ctas=1 if c['m']==128 else 2
if a.mode=='w4a16':
 from flashinfer.fused_moe.cute_dsl.blackwell import moe_w4a16 as host
 mp.setattr(host,'get_max_active_clusters',lambda count:2)
 original_compile=host._get_compiled_kernel;signature=inspect.signature(original_compile)
 def compile(*args,**kwargs):
  bound=signature.bind(*args,**kwargs);bound.arguments['use_clc_scheduler']=c['clc'];return original_compile(*bound.args,**bound.kwargs)
 mp.setattr(host,'_get_compiled_kernel',compile)
 t=((c['m'],c['n'],256),(ctas,1),True);tactic=(t,t)
else:
 from flashinfer.fused_moe.cute_dsl.blackwell import moe_swap_ab as host
 launch=host._run_blockscaled_gemm
 def bounded(*args,**kwargs):return launch(*args,**dict(kwargs,sm_count=2))
 if os.environ.get('SMOKE_NATIVE_SCHEDULER')!='1':mp.setattr(host,'_run_blockscaled_gemm',bounded)
 else:receipt['control_boundary']='Existing exact oracle with native SM budget and production scheduler selection; no performance timing or autotuning.'
 t=((c['m'],c['n']),(ctas,1),False);tactic=(c['n'],t,t,(a.k_steps,a.k_steps),c['clc']);receipt['tactic']=tactic
plan=existing._observe_swap_ab_mma_plans.__wrapped__();next(plan)
try:
 existing.TestCuteDslFusedMoeFunctional()._run_numerical_accuracy(activation_type=getattr(ActivationType,a.activation),num_tokens=c['tokens'],top_k=2,hidden_size=c['h'],intermediate_size=c['i'],num_experts=2,quant_mode='w4a4' if a.mode=='per-token' else a.mode,use_per_token_activation=a.mode=='per-token',use_fused_finalize=False,swap_ab=c['swap'],tactic=tactic)
 torch.cuda.synchronize();receipt.update(passed=True,finished=time.time());save();print(json.dumps(receipt))
except BaseException as e:
 receipt.update(passed=False,error=repr(e),finished=time.time());save();raise
finally:
 try:next(plan)
 except StopIteration:pass
 mp.undo()
