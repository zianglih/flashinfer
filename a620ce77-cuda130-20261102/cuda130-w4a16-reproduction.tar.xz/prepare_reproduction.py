"""Prepare standalone replay inputs without duplicating historical timing arrays."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
TASK = HERE.parent
PROJECT = TASK.parent
OUT = HERE / "reproduction"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def main():
    OUT.mkdir(exist_ok=True)
    for path in (TASK / "harness").rglob("*.py"):
        if "__pycache__" in path.parts:
            continue
        dest = OUT / path.relative_to(TASK)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, dest)
    shutil.copyfile(TASK / "harness/jobs.json", OUT / "harness/jobs.json")
    shutil.copyfile(TASK / "harness/frozen-provenance.json", OUT / "harness/original-frozen-provenance.json")
    projection = []
    for source in sorted((TASK / "harness/frozen").rglob("*")):
        if not source.is_file() or source.name == "before-historical-receipt.json":
            continue
        dest = OUT / source.relative_to(TASK)
        dest.parent.mkdir(parents=True, exist_ok=True)
        if source.name.endswith("-expected.json"):
            data = json.loads(source.read_text())
            compact = {k: data[k] for k in ("complete", "swap_ab", "use_fused_finalize")}
            compact["rows"] = [{k: row[k] for k in ("tokens", "backend_labels", "routing_identity")} for row in data["rows"]]
            compact["native_diagnostic"] = {"measurements": [{"cache_hits": m["cache_hits"]} for m in data["native_diagnostic"]["measurements"]]}
            assert len(compact["rows"]) == len(compact["native_diagnostic"]["measurements"]) == 13
            assert all(h["hit"] for m in compact["native_diagnostic"]["measurements"] for h in m["cache_hits"])
            assert all("milliseconds" not in m for m in compact["native_diagnostic"]["measurements"])
            write(dest, compact)
            projection.append(dict(source_path=str(source.relative_to(PROJECT)), source_sha256=sha(source),
                projected_path=str(dest.relative_to(OUT)), projected_sha256=sha(dest),
                field_projection="complete,swap_ab,use_fused_finalize; rows[tokens,backend_labels,routing_identity]; native_diagnostic.measurements[cache_hits]",
                timing_arrays_retained=False, choices_routes_and_order_preserved=True))
        else:
            shutil.copyfile(source, dest)
            assert sha(source) == sha(dest)
    write(OUT / "historical-input-projection.json", dict(passed=True, files=projection,
        original_manifest_sha256=sha(TASK / "harness/frozen-provenance.json"),
        boundary="Replay-only compact projection of historical route/winner expectations. Original run provenance and source hashes remain unchanged. No historical latency arrays enter fresh reports or this archive."))
    write(OUT / "harness/frozen-provenance.json", dict(
        files={str(p.relative_to(OUT)): sha(p) for p in sorted((OUT / "harness/frozen").rglob("*")) if p.is_file()},
        tokens=[1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 4096, 8192, 16384],
        boundary="COMPACT REPLAY MANIFEST, not the original measured-run input manifest. Exact cache files plus projected route/winner dictionaries; projection proof is ../historical-input-projection.json."))
    for name in ("before", "after"):
        dest = OUT / "sources" / (name + "-manifest.json")
        dest.parent.mkdir(exist_ok=True)
        shutil.copyfile(TASK / "sources" / dest.name, dest)
    adapter = PROJECT.parent / "flashinfer-w4a4-split-dynamic-n/old-cute-comparison-20261027/model-provenance/before-mx-parser-fix/benchmark-nemo.py"
    assert sha(adapter) == "8078d09b8be9c5a992d8904ffc59fbcdb28fd2e34324a69e4fe250ed79477eab"
    shutil.copyfile(adapter, OUT / "sources/before-benchmark-adapter.py")
    revisions = {}
    for name in ("before", "after"):
        manifest = json.loads((TASK / "sources" / (name + "-manifest.json")).read_text())
        head = manifest["head"]
        submodules = {}
        for sub in ("cccl", "cutlass", "nixl", "spdlog"):
            path = "3rdparty/" + sub
            submodules[path] = subprocess.check_output(["git", "-C", str(PROJECT / "flashinfer"), "rev-parse", head + ":" + path], text=True).strip()
        revisions[name] = dict(head=head, submodules=submodules, source_manifest_sha256=sha(OUT / "sources" / (name + "-manifest.json")),
            benchmark_adapter_sha256=sha(adapter) if name == "before" else None)
    write(OUT / "source-revisions.json", dict(repository="https://github.com/zianglih/flashinfer.git", sources=revisions))
    (OUT / "audits").mkdir(exist_ok=True)
    for name in ("analyze_cuda130.py", "verify_publication.py", "check_public_text.py"):
        shutil.copyfile(TASK / "audits" / name, OUT / "audits" / name)
    print(json.dumps(dict(complete=True, compact_expectations=len(projection), sources=revisions,
        projection_sha256=sha(OUT / "historical-input-projection.json")), indent=2))


if __name__ == "__main__":
    main()
