"""Render complete, independently audited CUDA 13.0 W4A16 evidence.

Only structured audit/raw JSON supplies numerical results. Native stdout is
linked unchanged; rendered native tables are never parsed. Without --audit,
--preview produces a plainly labeled layout preview with no numerical data.
"""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import shutil

import matplotlib
matplotlib.use("Agg")
import matplotlib.colors as colors
import matplotlib.pyplot as plt
import numpy as np

HERE = Path(__file__).resolve().parent
TASK = HERE.parent
MODELS = [("v3", "V3", 8), ("v41-flash", "V41F", 4),
          ("kimi-k3", "K3", 8), ("nemo3-ultra", "N3U", 8)]
TOKENS = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 4096, 8192, 16384]
PHASES = ["0-before", "1-after", "2-after", "3-before"]
HEADS = {"before": "002529e17b22567a071091053c6c4dc2a55e050e",
         "after": "a620ce7790b32f7f0ae524a811417d2c6cee1152"}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def column_order():
    return [(top, model, f"{label} {top.upper()}{degree}")
            for top in ("ep", "tp") for model, label, degree in MODELS]


def load_audit(path):
    audit = json.loads(path.read_text())
    summary = audit["summary"]
    assert summary["complete"] and summary["jobs"] == 8
    assert (summary["cells"], summary["retention_cells"], summary["raw_samples"]) == (104, 88, 41600)
    lookup = {}
    for job in audit["jobs"]:
        for cell in job["cells"]:
            topology = "ep" if cell["ep"] > 1 else "tp"
            key = (topology, cell["model"], cell["token"])
            assert key not in lookup
            assert cell["retention"] == (cell["token"] > 2)
            assert all(math.isfinite(cell[key]) and cell[key] > 0 for key in ("before_us", "after_us"))
            assert math.isclose(cell["speedup_percent"], 100 * (cell["before_us"] / cell["after_us"] - 1), abs_tol=1e-10)
            assert all(len(cell["phase_us"][role]) == 2 for role in HEADS)
            lookup[key] = cell
    assert set(lookup) == {(top, model, token) for top, model, _ in column_order() for token in TOKENS}
    return audit, lookup


def plot(lookup, out, audit_path=None):
    plt.rcParams.update({"font.family": "DejaVu Sans", "svg.fonttype": "none"})
    columns = column_order()
    ordered = [lookup.get((top, model, token)) for token in TOKENS[2:] for top, model, _ in columns]
    values = np.array([c["speedup_percent"] if c else np.nan for c in ordered]).reshape(11, 8)
    cmap = colors.LinearSegmentedColormap.from_list("red_white_green", ["#b2182b", "#ffffff", "#1a9850"])
    cmap.set_bad("#eef2f6")
    norm = colors.TwoSlopeNorm(vmin=-50, vcenter=0, vmax=100)
    fig, ax = plt.subplots(figsize=(13.5, 7.5), facecolor="white")
    fig.subplots_adjust(left=.085, right=.975, top=.785, bottom=.22)
    im = ax.imshow(np.ma.masked_invalid(values), cmap=cmap, norm=norm, aspect="auto", interpolation="nearest")
    ax.set_xticks(range(8), [label for _, _, label in columns], fontsize=11)
    ax.xaxis.tick_top()
    ax.set_yticks(range(11), [f"{t:,}" for t in TOKENS[2:]], fontsize=11)
    ax.tick_params(length=0, pad=9)
    ax.set_xticks(np.arange(-.5, 8, 1), minor=True)
    ax.set_yticks(np.arange(-.5, 11, 1), minor=True)
    ax.grid(which="minor", color="white", linewidth=.8)
    ax.tick_params(which="minor", length=0)
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.axvline(3.5, color="#253447", lw=1.6)
    ax.axhline(7.5, color="#69778a", lw=.9, linestyle=(0, (3, 3)))
    for row in range(11):
        for col in range(8):
            cell = ordered[row * 8 + col]
            value = values[row, col]
            star = cell and max(cell["repeat_spread_percent"].values()) > 1
            label = "pending" if cell is None else f"{value:+.2f}%" + ("*" if star else "")
            ax.text(col, row, label, ha="center", va="center", fontsize=10,
                    color="#768396" if cell is None else "white" if (value < -38 or value > 76) else "#17212d")
    title = "W4A16 · CUDA 13.0 runtime · before / after"
    if not lookup:
        title += " · LAYOUT PREVIEW"
    fig.text(.035, .965, title, fontsize=20, weight="bold", color="#18283c", va="top")
    fig.text(.035, .918, "B300 · fresh C–A–A–C · frozen per-arm tactics · strict CUPTI", fontsize=11, color="#526174")
    fig.text(.035, .88, "002529e1: original 64-row layout + prepare  →  a620ce77: 16-row layout + FC1 gather", fontsize=10, color="#526174")
    fig.text(.035, .85, "N3U ReLU² has no gate/up interleave. EP/TP are rank-local shapes; no communication is timed.", fontsize=9.5, color="#526174")
    ax.text(-.01, 1.04, "Tokens", transform=ax.transAxes, ha="right", va="bottom", fontsize=10, color="#526174")
    cbax = fig.add_axes([.26, .155, .56, .019])
    cb = fig.colorbar(im, cax=cbax, orientation="horizontal", extend="both")
    cb.set_ticks([-50, -25, 0, 50, 100], labels=["−50%", "−25%", "0%", "+50%", "+100%"])
    cb.outline.set_visible(False)
    fig.text(.035, .103, "Positive = after faster: 100 × (GM of two before phase medians / GM of two after phase medians − 1).", fontsize=9.5, color="#37465a")
    fig.text(.035, .073, "* Either arm's phase-median repeat spread >1%. Colors saturate at −50%/+100%; labels are unclipped. Tokens 1–2 omitted.", fontsize=9.5, color="#37465a")
    fig.text(.035, .043, "Container CUDA 13.0.2 / system NVCC 13.0.88; CuTe DSL 4.8 embeds NVVM 13.4.59. Clock variation retained.", fontsize=9.5, color="#37465a")
    stem = "cuda130-w4a16-layout-preview" if not lookup else "cuda130-w4a16-before-after"
    outputs = {}
    for ext in ("png", "svg"):
        path = out / (stem + "." + ext)
        fig.savefig(path, dpi=180, facecolor="white", metadata={"Date": None} if ext == "svg" else None)
        outputs[path.name] = sha(path)
    plt.close(fig)
    write_json(out / (stem + "-manifest.json"), dict(preview=not bool(lookup), rows=11, columns=8,
        source_sha256=sha(audit_path) if audit_path else None, script_sha256=sha(__file__), outputs=outputs,
        stars=sum(bool(c and max(c["repeat_spread_percent"].values()) > 1) for c in ordered),
        negative=sum(bool(c and c["speedup_percent"] < 0) for c in ordered),
        cells=[dict(row=i // 8, column=i % 8, token=TOKENS[2:][i // 8], label=columns[i % 8][2],
                    value=c["speedup_percent"] if c else None,
                    star=bool(c and max(c["repeat_spread_percent"].values()) > 1)) for i, c in enumerate(ordered)]))


def tables(audit, lookup, data_root, out):
    table = ["# CUDA 13.0 W4A16: all absolute and phase results", "",
             "Fresh C–A–A–C on one GPU per model/topology. All latencies are µs. Before/after are the geometric means of their two phase medians. Each phase has 100 strict CUPTI samples; tokens 1/2 are shown but excluded from aggregates. Native outputs are linked byte-for-byte below. No rendered tables were parsed.", ""]
    fields = ["model", "tokens", "retention", "c1_us", "a1_us", "a2_us", "c2_us", "before_us", "after_us", "speedup_percent", "before_repeat_percent", "after_repeat_percent", "conservative_speedup_percent"]
    records, native = [], []
    for top, model, label in column_order():
        table += ["## " + label, "", "| Tokens | C1 µs | A1 µs | A2 µs | C2 µs | Before µs | After µs | Speedup |", "|---:|---:|---:|---:|---:|---:|---:|---:|"]
        for token in TOKENS:
            c = lookup[top, model, token]
            b, a = c["phase_us"]["before"], c["phase_us"]["after"]
            star = "*" if max(c["repeat_spread_percent"].values()) > 1 else ""
            table.append(f"| {token:,} | {b[0]:.3f} | {a[0]:.3f} | {a[1]:.3f} | {b[1]:.3f} | {c['before_us']:.3f} | {c['after_us']:.3f} | {c['speedup_percent']:+.2f}%{star} |")
            records.append(dict(model=label, tokens=token, retention=c["retention"], c1_us=b[0], a1_us=a[0], a2_us=a[1], c2_us=b[1], before_us=c["before_us"], after_us=c["after_us"], speedup_percent=c["speedup_percent"], before_repeat_percent=c["repeat_spread_percent"]["before"], after_repeat_percent=c["repeat_spread_percent"]["after"], conservative_speedup_percent=c["conservative_speedup_percent"]))
        job_name = f"{top}-{model}-w4a16"
        job = next(j for j in audit["jobs"] if j["job"] == job_name)
        source = data_root / job_name
        receipt_path = source / "receipt.json"
        assert sha(receipt_path) == job["receipt_sha256"]
        receipt = json.loads(receipt_path.read_text())
        assert {role: receipt["sources"][role]["head"] for role in HEADS} == HEADS
        links = []
        for phase, phase_label in zip(receipt["phases"], PHASES):
            log = source / (phase_label + ".log")
            assert sha(log) == phase["stdout_sha256"]
            target = out / "native-output" / job_name / log.name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(log, target)
            assert sha(target) == sha(log)
            native.append(dict(job=job_name, phase=phase_label, path=str(target.relative_to(out)), sha256=sha(target)))
            links.append(f"[{phase_label}](native-output/{job_name}/{log.name})")
        table += ["", "Original native stdout: " + ", ".join(links) + ".", ""]
    table += ["`*` means either arm's repeat spread `(max phase median / min phase median − 1) × 100` exceeds 1%. This is a variability marker, not a significance test. CSV also includes the conservative `min(before) / max(after) − 1` result.", ""]
    (out / "tables.md").write_text("\n".join(table))
    with (out / "tables.csv").open("w") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(records)
    write_json(out / "native-output-manifest.json", dict(original_output_unchanged=True, logs=native))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--audit", type=Path)
    p.add_argument("--data-root", type=Path)
    p.add_argument("--output", type=Path, default=HERE)
    p.add_argument("--preview", action="store_true")
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    if args.preview:
        assert args.audit is None and args.data_root is None
        plot({}, args.output)
        return
    assert args.audit and args.data_root
    audit, lookup = load_audit(args.audit)
    data_root = args.data_root / "results" if (args.data_root / "results").is_dir() else args.data_root
    tables(audit, lookup, data_root, args.output)
    plot(lookup, args.output, args.audit)
    write_json(args.output / "report-inputs.json", dict(complete=True, audit_sha256=sha(args.audit),
        audit=str(args.audit.resolve()), sources=HEADS, fresh_cases=104, retention_cases=88,
        fresh_samples=41600, script_sha256=sha(__file__), raw_tables_parsed=False,
        outputs={name: sha(args.output / name) for name in ("tables.md", "tables.csv",
            "native-output-manifest.json", "cuda130-w4a16-before-after.png",
            "cuda130-w4a16-before-after.svg", "cuda130-w4a16-before-after-manifest.json")}))


if __name__ == "__main__":
    main()
