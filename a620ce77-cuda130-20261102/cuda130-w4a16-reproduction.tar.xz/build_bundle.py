"""Package fresh CUDA 13.0 evidence into explicit incremental archives (<100 MB).

No GitHub writes. Full historical campaigns, source tarballs, compiled caches,
layout previews and PR drafts are excluded. The two raw archives retain original
fresh JSON/stdout/telemetry byte-for-byte; compact historical contracts belong to
the separate metadata/reproduction archive.
"""
import argparse
import hashlib
import io
import json
import lzma
from pathlib import Path
import tarfile
from build_report import load_audit, sha

HERE = Path(__file__).resolve().parent
TASK = HERE.parent
LIMIT = 95_000_000


def archive(name, files):
    path = HERE / name
    temporary = HERE / (name + ".building")
    manifest = {key: dict(sha256=sha(value), bytes=value.stat().st_size) for key, value in sorted(files.items())}
    manifest_member = "archive-manifests/" + name.removesuffix(".tar.xz") + ".json"
    embedded = json.dumps(dict(files=manifest, original_bytes_preserved=True), indent=2).encode() + b"\n"
    with lzma.open(temporary, "wb", format=lzma.FORMAT_XZ, check=lzma.CHECK_CRC64, preset=6) as xz:
        with tarfile.open(fileobj=xz, mode="w|") as tar:
            for rel, source in sorted(files.items()):
                assert not Path(rel).is_absolute() and ".." not in Path(rel).parts
                data = source.read_bytes()
                info = tarfile.TarInfo(rel)
                info.mode, info.mtime, info.size = 0o644, 0, len(data)
                tar.addfile(info, io.BytesIO(data))
            info = tarfile.TarInfo(manifest_member)
            info.mode, info.mtime, info.size = 0o644, 0, len(embedded)
            tar.addfile(info, io.BytesIO(embedded))
    assert temporary.stat().st_size < LIMIT, f"Split this archive further before publication: {temporary}"
    temporary.replace(path)
    with tarfile.open(path, "r:xz") as tar:
        assert set(tar.getnames()) == set(files) | {manifest_member}
        for rel, item in manifest.items():
            assert hashlib.sha256(tar.extractfile(rel).read()).hexdigest() == item["sha256"], rel
    return dict(name=name, bytes=path.stat().st_size, sha256=sha(path), members=len(files), files=manifest, member_manifest=manifest_member)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--audit", type=Path, required=True)
    p.add_argument("--data-root", type=Path, required=True)
    p.add_argument("--qualification", type=Path, required=True, help="Audited compiler identity; generated PTX may explicitly be unavailable")
    p.add_argument("--run-provenance", type=Path, default=TASK / "evidence", help="Original executed config, rebind/bootstrap and final campaign/source receipts")
    args = p.parse_args()
    audit, _ = load_audit(args.audit)
    root = args.data_root / "results" if (args.data_root / "results").is_dir() else args.data_root
    report = json.loads((HERE / "report-inputs.json").read_text())
    assert report["audit_sha256"] == sha(args.audit)
    run_config = args.run_provenance / "config.json"
    assert run_config.is_file()
    raw = {"ep": {}, "tp": {}}
    for job in audit["jobs"]:
        source = root / job["job"]
        assert sha(source / "receipt.json") == job["receipt_sha256"]
        assert json.loads((source / "receipt.json").read_text())["config_sha256"] == sha(run_config)
        topology = job["job"].split("-")[0]
        for path in sorted(source.rglob("*")):
            if not path.is_file() or path.suffix not in (".json", ".jsonl", ".log", ".txt", ".csv"):
                continue
            rel = path.relative_to(source)
            if any(part.startswith(("cache-", "triton", "compiler-")) or "compiler-artifacts" in part for part in rel.parts):
                continue
            raw[topology][str(Path("results") / job["job"] / rel)] = path
    artifacts = [archive(f"cuda130-w4a16-raw-{topology}.tar.xz", files) for topology, files in raw.items()]
    metadata = {}
    for name in ["build_report.py", "build_bundle.py", "prepare_reproduction.py",
                 "tables.md", "tables.csv", "native-output-manifest.json", "report-inputs.json",
                 "cuda130-w4a16-before-after.png", "cuda130-w4a16-before-after.svg", "cuda130-w4a16-before-after-manifest.json"]:
        metadata[name] = HERE / name
    for path in (HERE / "reproduction").rglob("*"):
        if path.is_file() and "__pycache__" not in path.parts:
            metadata[str(path.relative_to(HERE))] = path
    for path in (TASK / "runtime").iterdir():
        if path.is_file():
            metadata["runtime/" + path.name] = path
    metadata["audit/audit.json"] = args.audit
    for name in ("config.json", "rebound/before/receipt.json", "rebound/after/receipt.json",
                 "source-data-bootstrap.json", "campaign-receipt.json", "source-postflight.json"):
        measured = args.run_provenance / name
        assert measured.is_file(), f"Missing original run provenance: {measured}"
        metadata["run-provenance/" + name] = measured
    native_root = args.run_provenance / "native-provenance"
    assert (native_root / "receipt.json").is_file()
    for path in native_root.rglob("*"):
        if path.is_file() and path.suffix in (".json", ".jsonl", ".log", ".txt", ".ninja"):
            metadata["run-provenance/" + str(path.relative_to(args.run_provenance))] = path
    for name in ("analyze_cuda130.py", "verify_publication.py", "check_public_text.py", "SETUP_REVIEW.md", "historical-inputs.json"):
        metadata["audit/" + name] = TASK / "audits" / name
    if args.qualification:
        metadata["audit/compiler-qualification.json"] = args.qualification
    original_dependencies = TASK.parent / "publication-pr7290-a620/dependencies.json"
    dependency = json.loads(original_dependencies.read_text())
    dependency = dict(required_for_fresh_measurement_replay=False,
        boundary="Context links only; no historical timing arrays enter this fresh comparison. New compact frozen choices/routes and source adapter are retained once in reproduction/.",
        prior_publication_root="https://raw.githubusercontent.com/zianglih/flashinfer/8cfecaf8964ffe61dfa6864c9b5250dfe298dac2/a620ce77",
        prior_dependency_manifest_sha256=sha(original_dependencies), historical_complete_archive=dependency["historical_complete_archive"])
    (HERE / "dependencies.json").write_text(json.dumps(dependency, indent=2) + "\n")
    metadata["dependencies.json"] = HERE / "dependencies.json"
    artifacts.append(archive("cuda130-w4a16-reproduction.tar.xz", metadata))
    manifest = dict(complete=True, fresh_cases=104, retention_cases=88, fresh_samples=41600,
        audit_sha256=sha(args.audit), artifacts=artifacts, measured_run_config_sha256=sha(run_config),
        original_run_provenance_preserved=True, old_raw_arrays_duplicated=False,
        full_source_tarballs_duplicated=False, native_stdout_original=True, each_blob_below_100mb=True,
        historical_expectations_are_explicit_compact_projections=True,
        boundary="Incremental fresh CUDA 13.0 evidence. Three deterministic, individually verified archives. Root still owns visual QA and public asset publication.")
    (HERE / "bundle-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    index = ["# CUDA 13.0 W4A16 evidence", "", "All 104 cases and 41,600 samples are fresh CUDA 13.0 measurements. Tokens 1/2 remain in raw files; 88 cases contribute to plots and aggregates. Extract both raw archives into the same directory to replay the independent analyzer. Original native stdout is also linked from [the full absolute/CAAC tables](tables.md).", "", "| Archive | Bytes | SHA256 |", "|---|---:|---|"]
    for item in artifacts:
        index.append(f"| [{item['name']}]({item['name']}) | {item['bytes']:,} | `{item['sha256']}` |")
    index += ["", "The reproduction archive includes source and runtime manifests, the benchmark adapter, exact cache choices, compact historical route/winner expectations, independent analysis and all table/plot source. Original historical timing arrays, full source tarballs and compiled caches are excluded. [Manifest](bundle-manifest.json) lists and hashes every member; [historical context dependencies](dependencies.json) remain immutable external references and are not needed for the fresh timing replay.", ""]
    (HERE / "evidence-index.md").write_text("\n".join(index))
    print(json.dumps({a["name"]: {k: a[k] for k in ("bytes", "sha256", "members")} for a in artifacts}, indent=2))


if __name__ == "__main__":
    main()
