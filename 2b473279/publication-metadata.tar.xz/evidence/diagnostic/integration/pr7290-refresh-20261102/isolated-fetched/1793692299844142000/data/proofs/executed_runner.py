from pathlib import Path
import json,hashlib,subprocess,time
D=Path('/data/ziangli/flashinfer-moe-gather-pipeline/integration/pr7290-refresh-20261102')
proposal=json.loads((D/'isolation-proposal.json').read_text());main=json.loads((D/'data/campaign.json').read_text());assert main['complete']and main['passed'];c=json.loads((D/'data/perf-config.json').read_text());selected=proposal['selected_jobs'];c['jobs']={name:j for name,j in c['jobs'].items()if name in selected}
for name,j in c['jobs'].items():j['tokens']=selected[name];j['expected_cells']=len(j['tokens'])*len(j['expected_backends'])
assert sum(j['expected_cells']for j in c['jobs'].values())==12 and len(c['jobs'])==8
out=D/'isolated';out.mkdir(exist_ok=False);c.update(phases=['candidate','control','control','candidate'],output=str(out/'results'),label='PR7290 serial originalGPU ACCA diagnostic',boundary='Predeclared diagnostic: all retention losses below-2%, plus stable1-2% losses (both spreads<=0.5%; all clock samples2032/reason0); retain paired MX dtype arms. Serial originalGPUs, stockclocks/power,10warmups100strictCUPTIcoldL2samples. Original mainmatrix untouched; no substitution into publication.')
(out/'perf-config.json').write_text(json.dumps(c,indent=2,sort_keys=True)+'\n')
gpus={row['job']:row['gpu']for lane in main['lanes'].values()for row in lane}
plan=dict(sealed=True,created=time.time(),order=list(c['jobs']),gpus={name:gpus[name]for name in c['jobs']},tokens=selected,cells=12,phases=c['phases'],raw_samples=4800,config_sha256=hashlib.sha256((out/'perf-config.json').read_bytes()).hexdigest(),proposal_sha256=hashlib.sha256((D/'isolation-proposal.json').read_bytes()).hexdigest(),selection_rule=proposal['boundary'],publication_replaces_original=False,authorized_by_parent=True)
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print('SEALED',json.dumps(plan),flush=True)
from pathlib import Path
import hashlib,json,subprocess,time
from concurrent.futures import ThreadPoolExecutor
D=Path('/data/ziangli/flashinfer-moe-gather-pipeline/integration/pr7290-refresh-20261102');H=D/'payload/harness';config=D/'isolated/perf-config.json';c=json.loads(config.read_text());main=json.loads((D/'data/campaign.json').read_text());assert main['complete']and main['passed']
plan=json.loads((D/'isolated/plan.json').read_text());assert set(plan['order'])==set(c['jobs']);assert c['phases']==['candidate','control','control','candidate']
r=dict(complete=False,started=time.time(),plan_sha256=hashlib.sha256((D/'isolated/plan.json').read_bytes()).hexdigest(),jobs=[])
def verify_sources():
 proof={}
 for role,source in c['sources'].items():
  mf=Path(source['tracked_manifest']);assert hashlib.sha256(mf.read_bytes()).hexdigest()==source['tracked_manifest_sha256'];files=json.loads(mf.read_text())
  def check(item):
   name,digest=item;assert hashlib.sha256((Path(source['repo'])/name).read_bytes()).hexdigest()==digest,(role,name)
  with ThreadPoolExecutor(max_workers=32)as pool:list(pool.map(check,files.items()))
  proof[role]=dict(files=len(files),manifest_sha256=source['tracked_manifest_sha256'])
 return proof
r['full_source_before']=verify_sources()
for name in plan['order']:
 assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
 gpu=plan['gpus'][name];start=time.time()
 with(D/'isolated'/(name+'.log')).open('w')as log:p=subprocess.run([c['python'],str(H/'run_perf.py'),'--config',str(config),'--job',name,'--gpu',str(gpu)],stdout=log,stderr=subprocess.STDOUT)
 row=dict(job=name,gpu=gpu,returncode=p.returncode,started=start,finished=time.time());r['jobs'].append(row);(D/'isolated/receipt.json').write_text(json.dumps(r,indent=2)+'\n');p.check_returncode()
 subprocess.run([c['python'],str(H/'analyze_perf.py'),str(Path(c['output'])/name)],stdout=subprocess.DEVNULL,check=True)
 print('DONE',name,flush=True)
r['full_source_after']=verify_sources()
r.update(complete=True,passed=True,finished=time.time());(D/'isolated/receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
