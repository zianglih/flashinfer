from pathlib import Path
import argparse,copy,hashlib,json,sys,time
H=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=argparse.ArgumentParser();a.add_argument('--role',required=True);a.add_argument('--repo',required=True);a=a.parse_args();assert a.role in ('control','candidate');sys.path.insert(0,a.repo)
from flashinfer.autotune_cache import ManagedAutotuneCache,_decode_key_fields,_encode_key_fields
from flashinfer.autotuner.autotuner import _collect_metadata
metadata=_collect_metadata();root=H/'rebound-cache'/a.role;root.mkdir(parents=True,exist_ok=False)
proof=json.loads((H/'frozen-inputs/provenance.json').read_text());jobs={};rows=[]
for name in json.loads((H/'jobs-full.json').read_text()):
 frozen=H/'frozen-inputs'/name
 assert sha(frozen/'expected.json')==proof[name]['compact_expected_sha256']
 for rel,digest in proof[name]['cache_manifest'].items():assert sha(frozen/'cache'/rel)==digest
 mf,=list((frozen/'cache/v2').glob('*/manifest.json'));old=json.loads(mf.read_text());extra={k:v for k,v in old.items()if k not in metadata and k!='cache_schema'};assert set(extra)<={'measure_execution_mode'}
 native=ManagedAutotuneCache(dict(metadata,**extra),root=root/name);native.entries_dir.mkdir(parents=True);(native.env_dir/'manifest.json').write_text(json.dumps(native.manifest,indent=2,sort_keys=True)+'\n');mapping={}
 for original in (mf.parent/'entries').glob('*.json'):
  d=json.loads(original.read_text());assert d['runner'] in ('CuteDslFusedMoERunner','CuteDslFusedMoEW4A16Runner');fields=_decode_key_fields(d['key_fields']);assert repr(fields)==d['key'];key=d['key'];entry=copy.deepcopy(d)
  if a.role=='candidate':
   extras=list(fields[-1]);index=3 if d['runner']=='CuteDslFusedMoEW4A16Runner' else 8
   assert extras[index]==0,(d['runner'],extras)
   del extras[index];fields=(*fields[:-1],tuple(extras));entry['key']=repr(fields);entry['key_fields']=_encode_key_fields(fields)
  assert entry['key']not in mapping.values();mapping[key]=entry['key'];dest=native._entry_path(entry['key']);dest.write_text(json.dumps(entry,indent=2,sort_keys=True)+'\n')
  assert {k:v for k,v in d.items()if k not in ('key','key_fields')}=={k:v for k,v in entry.items()if k not in ('key','key_fields')}
 expected=json.loads((frozen/'expected.json').read_text());measurements=iter(expected['native_diagnostic']['measurements'])
 for row in expected['rows']:
  for result in row['results']:
   m=next(measurements);h=m['cache_hits'][0];assert all(all(x[k]==h[k]for k in ('key','runner','tactic','profiling_policy'))for x in m['cache_hits'])
   actual=native.lookup(mapping[h['key']]);assert actual is not None and (actual.runner,actual.tactic,list(actual.profiling_policy))==(h['runner'],h['tactic'],h['profiling_policy'])
   rows.append(dict(job=name,tokens=row['tokens'],backend=result['backend'],old_key=h['key'],key=mapping[h['key']],tactic=actual.tactic))
 assert next(measurements,None)is None
 (root/(name+'-keys.json')).write_text(json.dumps(mapping,indent=2,sort_keys=True)+'\n')
 jobs[name]=dict(env_hash=native.env_hash,manifest=native.manifest,cache_manifest={str(p.relative_to(root/name)):sha(p)for p in(root/name).rglob('*')if p.is_file()},key_map_sha256=sha(root/(name+'-keys.json')))
assert len(rows)==468 and sum(r['tactic']==-1 for r in rows)==10
record=dict(passed=True,role=a.role,metadata=metadata,jobs=jobs,rows=rows,no_retuning=True,all_tactics_policy_routes_preserved=True,changes='Environment namespace metadata and audited local_expert_offset key removal only for candidate; no runtime argument changes')
(H/('cache-import-'+a.role+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(a.role,len(rows),flush=True)
