import argparse,hashlib,json,os,subprocess,sys,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--role',required=True);a=p.parse_args();D=Path(__file__).resolve().parents[2];c=json.loads((D/'payload/data/perf-config.json').read_text());s=c['sources'][a.role]
os.environ.update(CUDA_VISIBLE_DEVICES='0' if a.role=='control'else'1',FLASHINFER_WORKSPACE_BASE=s['workspace_base'],FLASHINFER_CUBIN_DIR=s['cubin_dir'],CUTE_DSL_CACHE_DIR=s['cute_cache'],CUDA_CACHE_PATH=c['driver_cache'],FLASHINFER_CUDA_ARCH_LIST='10.3a',FLASHINFER_CUTE_DSL_STRICT_CACHE_KEY='1',FLASHINFER_DIST_AWARE_AUTOTUNE='0',TRTLLM_ENABLE_PDL='1',FLASHINFER_DISABLE_FP4_QUANT_FAST_MATH='0',TRTLLM_DISABLE_FP4_QUANT_FAST_MATH='0',MAX_JOBS='4',OMP_NUM_THREADS='1',FLASHINFER_JIT_BUILD_LOG=str(D/('warm-native-'+a.role+'.jsonl')))
sys.path.insert(0,s['repo'])
from flashinfer.jit.moe_utils import gen_moe_utils_module
from flashinfer.jit.fp4_quantization import gen_fp4_quantization_sm103_module
from flashinfer.jit.fp8_quantization import gen_mxfp8_quantization_sm100_module
from flashinfer.jit.dsv3_optimizations import gen_dsv3_fused_routing_module
r=dict(complete=False,source=s,modules=[],started=time.time());out=D/('warm-native-'+a.role+'.json')
def save():out.write_text(json.dumps(r,indent=2)+'\n')
save()
for f in (gen_moe_utils_module,gen_fp4_quantization_sm103_module,gen_mxfp8_quantization_sm100_module,gen_dsv3_fused_routing_module):
 spec=f();assert spec.build_dir.resolve().is_relative_to(Path(s['workspace_base']));start=time.time();print('BUILD_START',spec.name,flush=True);spec.build_and_load()
 check=subprocess.run(['ninja','-C',str(spec.build_dir),'-n','-v'],capture_output=True,text=True);assert check.returncode==0 and 'no work to do'in check.stdout
 r['modules'].append(dict(name=spec.name,seconds=time.time()-start,library=str(spec.jit_library_path),library_sha256=hashlib.sha256(spec.jit_library_path.read_bytes()).hexdigest(),ninja=str(spec.ninja_path),ninja_sha256=hashlib.sha256(spec.ninja_path.read_bytes()).hexdigest(),noop=check.stdout));save();print('BUILD_DONE',spec.name,flush=True)
r.update(complete=True,finished=time.time());save()
