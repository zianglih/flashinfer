"""Audit a fetched snapshot and report every complete source-paired cell."""

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics
import tempfile

from analyze_perf import analyze

H = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()


def write_csv(path, rows):
    with path.open("w") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def gm(rows):
    return 100 * (math.exp(statistics.mean(math.log1p(r["speedup_percent"] / 100) for r in rows)) - 1)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("evidence", type=Path)
    args = parser.parse_args()
    root = args.evidence.resolve()
    fetch = json.loads((root.parent / "fetch-receipt.json").read_text())
    assert fetch["passed"]
    for rel, digest in fetch["files"].items():
        assert sha(root / rel) == digest, rel
    config_path = root / "perf-config.json"
    config = json.loads(config_path.read_text())
    cache_import = {role: json.loads((H / ("cache-import-" + role + ".json")).read_text()) for role in config["sources"]}
    assert all(v["passed"] and v["no_retuning"] for v in cache_import.values())
    campaign = json.loads((root / "campaign.json").read_text())
    assert campaign["config_sha256"] == sha(config_path)
    for role, source in config["sources"].items():
        tracked = root / Path(source["tracked_manifest"]).name
        assert sha(tracked) == source["tracked_manifest_sha256"]
        proof = campaign["full_source_before"][role]
        assert proof["manifest_sha256"] == sha(tracked)
        assert proof["files"] == len(json.loads(tracked.read_text()))
        if campaign.get("complete") and campaign.get("passed"):
            final = campaign["full_source_after"][role]
            assert final["manifest_sha256"] == sha(tracked) and final["files"] == proof["files"]
    rows, phase_rows, component_rows, clocks, guards = [], [], [], [], []
    raw_samples = default_stage_joins = 0
    for job_name in fetch["jobs"]:
        job = config["jobs"][job_name]
        folder = root / "results" / job_name
        receipt = json.loads((folder / "receipt.json").read_text())
        assert receipt["complete"] and receipt["sources"] == config["sources"]
        assert receipt["config_sha256"] == sha(config_path)
        assert receipt["observer_hashes"] == config["observer_hashes"]
        assert [p["role"] for p in receipt["phases"]] == config["phases"]
        for role in config["sources"]:
            imported = cache_import[role]["jobs"][job_name]
            assert receipt["winner_cache_manifests"][role] == imported["cache_manifest"]
            mapping_path = H / "rebound-cache" / role / (job_name + "-keys.json")
            assert sha(mapping_path) == imported["key_map_sha256"]
            assert receipt["cache_key_maps"][role] == json.loads(mapping_path.read_text())
        expected = json.loads((H / "frozen-inputs" / job_name / "expected.json").read_text())
        routes = {r["tokens"]: r["routing_identity"] for r in expected["rows"]}
        expected_measurements = iter(expected["native_diagnostic"]["measurements"])
        winners = {}
        for r in expected["rows"]:
            for result in r["results"]:
                m = next(expected_measurements)
                winners[(r["tokens"], result["backend"])] = list({json.dumps({k: hit[k] for k in ("key", "runner", "tactic")}, sort_keys=True): {k: hit[k] for k in ("key", "runner", "tactic")} for hit in m["cache_hits"]}.values())
        assert next(expected_measurements, None) is None
        analysis = json.loads((folder / "analysis.json").read_text())
        assert analysis["complete"] and analysis["receipt_sha256"] == sha(folder / "receipt.json")
        # Recompute timelines in a disposable output folder; fetched raw evidence
        # remains immutable, including the original derived-analysis file.
        with tempfile.TemporaryDirectory(dir=root.parent, prefix="component-audit-") as tmp:
            temporary = Path(tmp)
            for path in folder.iterdir():
                if path.name not in ("analysis.json", "component-samples.json"):
                    (temporary / path.name).symlink_to(path, target_is_directory=path.is_dir())
            assert analyze(temporary) == analysis
        actual_medians = {}
        for phase in receipt["phases"]:
            assert phase["verified"] and phase["returncode"] == 0
            label = f"{phase['index']}-{phase['role']}"
            data_path = folder / label / "results.json"
            assert sha(data_path) == phase["results_sha256"]
            data = json.loads(data_path.read_text())
            assert data["complete"] and data["profile_calls"] == 0 and not data["native_diagnostic"]["admitted_tactics"]
            assert data["swap_ab"] and not data["use_fused_finalize"]
            assert data["benchmark_sha256"] == config["sources"][phase["role"]]["source_sha256"]["benchmarks/bench_moe_deepseek.py"]
            assert phase["gpu_before"].split(",")[0] == phase["gpu_after"].split(",")[0] == receipt["gpu_initial"].split(",")[0]
            measurements = iter(data["native_diagnostic"]["measurements"])
            native_records = []
            for row in data["rows"]:
                assert row["routing_identity"] == routes[row["tokens"]]
                for result in row["results"]:
                    m = next(measurements)
                    assert m["timer"] == "CUPTI" and m["event_fallback_forbidden"] and len(m["milliseconds"]) == len(m["iter_timestamps"]) == 100
                    assert all(hit["hit"] for hit in m["cache_hits"])
                    selected = list({json.dumps({k: hit[k] for k in ("key", "runner", "tactic")}, sort_keys=True): {k: hit[k] for k in ("key", "runner", "tactic")} for hit in m["cache_hits"]}.values())
                    assert selected == [dict(h, key=receipt["cache_key_maps"][phase["role"]][h["key"]]) for h in winners[(row["tokens"], result["backend"])]]
                    if job.get("w4a16_only"):
                        selected_tactic = selected[0]["tactic"]
                        expected_tactic = config["default_w4a16_moe_tactic"] if selected_tactic == -1 else selected_tactic
                        resolved = m["w4_resolved_configs"]
                        assert len(resolved) == 2 and {x["stage"] for x in resolved} == {"fc1", "fc2"}
                        for native in resolved:
                            assert native["resolved_moe_tactic"] == expected_tactic
                            assert native["supplied_moe_tactic"] == (None if selected_tactic == -1 else selected_tactic)
                            stage = expected_tactic[0 if native["stage"] == "fc1" else 1]
                            assert native["mma_tiler_mnk"] == stage[0] and native["cluster_shape_mn"] == stage[1] and native["raster_along_m"] == stage[2]
                            native_records.append(native)
                            default_stage_joins += int(selected_tactic == -1)
                    assert statistics.median(m["milliseconds"]) == m["median_ms"] == result["latency_ms"]
                    actual_medians[(label, row["tokens"], result["backend"])] = m["median_ms"] * 1000
                    for ms, (begin, end) in zip(m["milliseconds"], m["iter_timestamps"]):
                        ids = {launch[2] for launch in m["launches"] if begin <= launch[0] <= end}
                        activity = [k for k in m["activities"] if k[3] in ids]
                        assert activity and math.isclose((max(k[2] for k in activity) - min(k[1] for k in activity)) / 1e6, ms, abs_tol=1e-12)
                    raw_samples += 100
            assert next(measurements, None) is None
            compiled_by_library = {}
            for guard in phase["register_guards"]:
                rel = Path(guard["path"]).relative_to(Path(config["output"]) / job_name)
                path = folder / rel
                assert sha(path) == guard["sha256"]
                g = json.loads(path.read_text())
                assert g["all_guarded"] and g["exitstatus"] == 0 and not g["compiler_options_changed"]
                kernel = "moe_w4a16_kernel.py" if job.get("w4a16_only") else "moe_swap_ab_kernel.py"
                assert g["kernel_sha256"] == config["sources"][phase["role"]]["source_sha256"]["flashinfer/fused_moe/cute_dsl/blackwell/" + kernel]
                assert g["policy"] == (dict(control=80, gather=64, epilogue=144) if job.get("w4a16_only") else config["register_policies"][phase["role"]])
                for compiled in g["compilations"]:
                    assert compiled["passed"] and compiled["analysis"]["local_bytes"] == 0
                    compiled_by_library[compiled["library_handle"]] = compiled
                    guards.append(dict(job=job_name, phase=label, gather_input=compiled["gather_input"], **compiled["analysis"]))
            for native in native_records:
                compiled = compiled_by_library[native["compiled_library"]]
                assert compiled["gather_input"] == (native["stage"] == "fc1")
                for field in ("mma_tiler_mnk", "cluster_shape_mn", "raster_along_m", "use_clc_scheduler", "enable_pdl"):
                    assert native[field] == compiled[field]
        for phase in analysis["phases"]:
            assert math.isclose(phase["medians"]["e2e_us"], actual_medians[(phase["phase"], phase["tokens"], phase["backend"])], abs_tol=1e-9)
            phase_rows.append(dict(job=job_name, tokens=phase["tokens"], backend=phase["backend"], phase=phase["phase"], role=phase["role"], **phase["medians"]))
            clocks.extend(dict(job=job_name, tokens=phase["tokens"], backend=phase["backend"], phase=phase["phase"], **q) for q in phase["quartiles"])
        assert len(analysis["cells"]) == job["expected_cells"]
        for cell in analysis["cells"]:
            v = cell["phase_us"]
            assert len(v["control"]) == len(v["candidate"]) == 2
            for role in ("control", "candidate"):
                actual = [actual_medians[(f"{p['index']}-{role}", cell["tokens"], cell["backend"])] for p in receipt["phases"] if p["role"] == role]
                assert all(math.isclose(x, y, abs_tol=1e-9) for x, y in zip(v[role], actual))
            speed = 100 * (math.sqrt(math.prod(v["control"]) / math.prod(v["candidate"])) - 1)
            assert math.isclose(speed, cell["speedup_percent"], abs_tol=1e-10)
            r = dict(job=job_name, model=job["model"], topology="tp" if job["tp"] > 1 else "ep", ep=job["ep"], tp=job["tp"], backend=cell["backend"], tokens=cell["tokens"], retention=cell["tokens"] >= 4,
                     c1_us=v["control"][0], a1_us=v["candidate"][0], a2_us=v["candidate"][1], c2_us=v["control"][1], control_us=cell["control_us"], candidate_us=cell["candidate_us"], speedup_percent=speed,
                     arithmetic_speedup_percent=100 * (sum(v["control"]) / sum(v["candidate"]) - 1), control_spread_percent=cell["repeat_spread_percent"]["control"], candidate_spread_percent=cell["repeat_spread_percent"]["candidate"],
                     clock_mhz="/".join(map(str, cell["clock_mhz"])), clock_reasons="/".join(cell["clock_reasons"]), source_label=config["label"], receipt_sha256=sha(folder / "receipt.json"))
            rows.append(r)
            component = {k: r[k] for k in ("job", "model", "topology", "backend", "tokens", "speedup_percent", "control_spread_percent", "candidate_spread_percent")}
            for key in cell["component_medians"]["control"]:
                if key.endswith(("_start_us", "_end_us")):
                    continue
                before = cell["component_medians"]["control"][key]
                after = cell["component_medians"]["candidate"][key]
                component["control_" + key] = before
                component["candidate_" + key] = after
                component["delta_" + key] = after - before
            component_rows.append(component)
    out = root.parent / "report"
    out.mkdir(exist_ok=True)
    write_csv(out / "cells.csv", rows)
    component_keys = sorted({k for row in phase_rows for k in row})
    write_csv(out / "phase-components.csv", [{k: r.get(k, "") for k in component_keys} for r in phase_rows])
    delta_keys = sorted({k for row in component_rows for k in row})
    write_csv(out / "component-deltas.csv", [{k: r.get(k, "") for k in delta_keys} for r in component_rows])
    groups = {}
    for category, values, selector in [
        ("band", ["decode", "middle", "prefill", "all"], lambda r: "decode" if r["tokens"] <= 64 else "middle" if r["tokens"] <= 512 else "prefill"),
        ("mode", sorted({r["backend"] for r in rows}), lambda r: r["backend"]),
        ("model_topology", sorted({r["model"] + "/" + r["topology"] for r in rows}), lambda r: r["model"] + "/" + r["topology"]),
        ("model_topology_mode", sorted({r["model"] + "/" + r["topology"] + "/" + r["backend"] for r in rows}), lambda r: r["model"] + "/" + r["topology"] + "/" + r["backend"]),
        ("implementation", ["swap_ab", "w4a16"], lambda r: "w4a16" if r["backend"] == "CuteDSL W4A16" else "swap_ab"),
    ]:
        for value in values:
            selected = [r for r in rows if r["retention"] and (value == "all" or selector(r) == value)]
            if selected:
                groups[category + "/" + value] = dict(cells=len(selected), speedup_percent=gm(selected), negative=sum(r["speedup_percent"] < 0 for r in selected), max_control_spread=max(r["control_spread_percent"] for r in selected), max_candidate_spread=max(r["candidate_spread_percent"] for r in selected))
    band_of = lambda r: "decode" if r["tokens"] <= 64 else "middle" if r["tokens"] <= 512 else "prefill"
    cross_groups = {}
    for key in sorted({(r["backend"], r["model"], r["topology"], band_of(r)) for r in rows if r["retention"]}):
        selected = [r for r in rows if r["retention"] and (r["backend"], r["model"], r["topology"], band_of(r)) == key]
        cross_groups["/".join(key)] = dict(cells=len(selected), speedup_percent=gm(selected), negative=sum(r["speedup_percent"] < 0 for r in selected))
    available = [q for q in clocks if q["clock"]["available"]]
    tight_losses = sorted((r for r in rows if r["retention"] and r["speedup_percent"] < 0 and max(r["control_spread_percent"], r["candidate_spread_percent"]) <= 0.5), key=lambda r: r["speedup_percent"])
    summary = dict(passed=True, complete_campaign=len(fetch["jobs"]) == len(config["jobs"]) and campaign.get("complete") and campaign.get("passed"), measured_cells=len(rows), retention_cells=sum(r["retention"] for r in rows), raw_samples=raw_samples, loaded_kernels=len(guards),
                   jobs=fetch["jobs"], pending_jobs=sorted(set(config["jobs"]) - set(fetch["jobs"])), groups=groups, clock_quartiles=len(clocks), missing_clock_quartiles=len(clocks)-len(available), default_stage_resource_joins=default_stage_joins,
                   clock_exception_quartiles=sum(q["clock"]["sm_mhz"]["median"] != 2032 or set(q["clock"]["reasons"]) != {"0"} for q in available),
                   config_sha256=sha(config_path), source_label=config["label"], control_head=config["control_head"], all_rows_retained=True, cross_groups=cross_groups,
                   audit_helper_sha256=sha(__file__), timeline_helper_sha256=sha(H / "analyze_perf.py"),
                   tight_negative_cells=tight_losses, tight_definition="Both phase-median repeat spreads <=0.5%; descriptive only, not statistical confidence. All other losses remain in the full table.",
                   estimator=config["estimator"], boundary="Only complete CAAC jobs; tokens 1/2 retained in raw rows but excluded from summaries. Clock/repeat anomalies retained. Components are per-phase medians; use extension/gap rather than adding overlapping kernel durations.")
    (out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    (out / "clock-quartiles.json").write_text(json.dumps(clocks, indent=2) + "\n")
    (out / "runtime-resources.json").write_text(json.dumps(guards, indent=2) + "\n")
    lines = ["| Model | EP/TP | Mode | Tokens | C1 µs | A1 µs | A2 µs | C2 µs | Speedup | C spread | A spread |", "|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for r in rows:
        lines.append(f"| {r['model']} | {r['topology'].upper()}{r[r['topology']]} | {r['backend']} | {r['tokens']} | {r['c1_us']:.3f} | {r['a1_us']:.3f} | {r['a2_us']:.3f} | {r['c2_us']:.3f} | {r['speedup_percent']:+.3f}% | {r['control_spread_percent']:.3f}% | {r['candidate_spread_percent']:.3f}% |")
    (out / "table.md").write_text("\n".join(lines) + "\n")
    (out / "retention-table.md").write_text("\n".join(lines[:2] + [line for line, row in zip(lines[2:], rows) if row["retention"]]) + "\n")
    groups_table = ["| Group | Cells | Speedup | Negative | Max C spread | Max A spread |", "|---|---:|---:|---:|---:|---:|"]
    for name, group in groups.items():
        groups_table.append(f"| {name} | {group['cells']} | {group['speedup_percent']:+.3f}% | {group['negative']} | {group['max_control_spread']:.3f}% | {group['max_candidate_spread']:.3f}% |")
    (out / "groups.md").write_text("\n".join(groups_table) + "\n")
    tokens = sorted({r["tokens"] for r in rows if r["retention"]})
    matrix = ["| Model | EP/TP | Mode | " + " | ".join(map(str, tokens)) + " |", "|---|---|---|" + "---:|" * len(tokens)]
    for model, topology, backend in sorted({(r["model"], r["topology"], r["backend"]) for r in rows}):
        selected = {r["tokens"]: r for r in rows if (r["model"], r["topology"], r["backend"]) == (model, topology, backend)}
        matrix.append(f"| {model} | {topology.upper()}{next(iter(selected.values()))[topology]} | {backend} | " + " | ".join(f"{selected[t]['speedup_percent']:+.3f}%" if t in selected else "pending" for t in tokens) + " |")
    (out / "matrix.md").write_text("\n".join(matrix) + "\n")
    print(json.dumps({k: summary[k] for k in ("passed", "complete_campaign", "measured_cells", "retention_cells", "raw_samples", "loaded_kernels", "groups", "missing_clock_quartiles", "clock_exception_quartiles")}))


if __name__ == "__main__":
    main()
